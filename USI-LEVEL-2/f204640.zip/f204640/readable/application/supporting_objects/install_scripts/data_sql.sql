begin
    --CHAT_MESSAGES: 37/10000 rows exported, APEX$DATA$PKG/CHAT_MESSAGES$473472
    apex_data_install.load_supporting_object_data(p_table_name => 'CHAT_MESSAGES', p_delete_after_install => true );
    --DBTOOLS$EXECUTION_HISTORY: 0/10000 rows exported, no file generated
    apex_data_install.load_supporting_object_data(p_table_name => 'DBTOOLS$EXECUTION_HISTORY', p_delete_after_install => true );
    --HTMLDB_PLAN_TABLE: 4/10000 rows exported, APEX$DATA$PKG/HTMLDB_PLAN_TABLE$923485
    apex_data_install.load_supporting_object_data(p_table_name => 'HTMLDB_PLAN_TABLE', p_delete_after_install => true );
    --L1_ANNOUNCEMENT: 14/10000 rows exported, APEX$DATA$PKG/L1_ANNOUNCEMENT$175257
    apex_data_install.load_supporting_object_data(p_table_name => 'L1_ANNOUNCEMENT', p_delete_after_install => true );
    --L1_BRANCH: 4/10000 rows exported, APEX$DATA$PKG/L1_BRANCH$767174
    apex_data_install.load_supporting_object_data(p_table_name => 'L1_BRANCH', p_delete_after_install => true );
    --L1_CLASSES: 20/10000 rows exported, APEX$DATA$PKG/L1_CLASSES$61750
    apex_data_install.load_supporting_object_data(p_table_name => 'L1_CLASSES', p_delete_after_install => true );
    --L1_EMAIL_TO_USN: 14/10000 rows exported, APEX$DATA$PKG/L1_EMAIL_TO_USN$487378
    apex_data_install.load_supporting_object_data(p_table_name => 'L1_EMAIL_TO_USN', p_delete_after_install => true );
    --L1_STUDENTS: 12/10000 rows exported, APEX$DATA$PKG/L1_STUDENTS$215208
    apex_data_install.load_supporting_object_data(p_table_name => 'L1_STUDENTS', p_delete_after_install => true );
    --L1_STUDENTS_ATTEND: 162/10000 rows exported, APEX$DATA$PKG/L1_STUDENTS_ATTEND$48394
    apex_data_install.load_supporting_object_data(p_table_name => 'L1_STUDENTS_ATTEND', p_delete_after_install => true );
    --L1_STUDENTS_MARKS: 30/10000 rows exported, APEX$DATA$PKG/L1_STUDENTS_MARKS$993782
    apex_data_install.load_supporting_object_data(p_table_name => 'L1_STUDENTS_MARKS', p_delete_after_install => true );
    --L1_SUBJECTS: 4/10000 rows exported, APEX$DATA$PKG/L1_SUBJECTS$146034
    apex_data_install.load_supporting_object_data(p_table_name => 'L1_SUBJECTS', p_delete_after_install => true );
    --L1_SUBJECT_DETAILS: 3/10000 rows exported, APEX$DATA$PKG/L1_SUBJECT_DETAILS$22998
    apex_data_install.load_supporting_object_data(p_table_name => 'L1_SUBJECT_DETAILS', p_delete_after_install => true );
    --L1_TEACHERS: 5/10000 rows exported, APEX$DATA$PKG/L1_TEACHERS$396159
    apex_data_install.load_supporting_object_data(p_table_name => 'L1_TEACHERS', p_delete_after_install => true );
    --L1_TESTS: 4/10000 rows exported, APEX$DATA$PKG/L1_TESTS$784697
    apex_data_install.load_supporting_object_data(p_table_name => 'L1_TESTS', p_delete_after_install => true );
    --L2_ANNOUNCEMENT: 4/10000 rows exported, APEX$DATA$PKG/L2_ANNOUNCEMENT$163579
    apex_data_install.load_supporting_object_data(p_table_name => 'L2_ANNOUNCEMENT', p_delete_after_install => true );
    --L2_BRANCH: 5/10000 rows exported, APEX$DATA$PKG/L2_BRANCH$418307
    apex_data_install.load_supporting_object_data(p_table_name => 'L2_BRANCH', p_delete_after_install => true );
    --L2_CHAT: 6/10000 rows exported, APEX$DATA$PKG/L2_CHAT$946750
    apex_data_install.load_supporting_object_data(p_table_name => 'L2_CHAT', p_delete_after_install => true );
    --L2_CLASSES: 2/10000 rows exported, APEX$DATA$PKG/L2_CLASSES$80689
    apex_data_install.load_supporting_object_data(p_table_name => 'L2_CLASSES', p_delete_after_install => true );
    --L2_NOTES: 3/10000 rows exported, APEX$DATA$PKG/L2_NOTES$904069
    apex_data_install.load_supporting_object_data(p_table_name => 'L2_NOTES', p_delete_after_install => true );
    --L2_STUDENTS: 21/10000 rows exported, APEX$DATA$PKG/L2_STUDENTS$113707
    apex_data_install.load_supporting_object_data(p_table_name => 'L2_STUDENTS', p_delete_after_install => true );
    --L2_STUDENTS_ATTEND: 20/10000 rows exported, APEX$DATA$PKG/L2_STUDENTS_ATTEND$790273
    apex_data_install.load_supporting_object_data(p_table_name => 'L2_STUDENTS_ATTEND', p_delete_after_install => true );
    --L2_STUDENTS_DETAILS: 0/10000 rows exported, no file generated
    apex_data_install.load_supporting_object_data(p_table_name => 'L2_STUDENTS_DETAILS', p_delete_after_install => true );
    --L2_STUDENTS_MARKS: 40/10000 rows exported, APEX$DATA$PKG/L2_STUDENTS_MARKS$975639
    apex_data_install.load_supporting_object_data(p_table_name => 'L2_STUDENTS_MARKS', p_delete_after_install => true );
    --L2_STUDENTS_SUBJECTS: 36/10000 rows exported, APEX$DATA$PKG/L2_STUDENTS_SUBJECTS$552436
    apex_data_install.load_supporting_object_data(p_table_name => 'L2_STUDENTS_SUBJECTS', p_delete_after_install => true );
    --L2_SUBJECTS: 11/10000 rows exported, APEX$DATA$PKG/L2_SUBJECTS$309637
    apex_data_install.load_supporting_object_data(p_table_name => 'L2_SUBJECTS', p_delete_after_install => true );
    --L2_SUBJECT_DETAILS: 7/10000 rows exported, APEX$DATA$PKG/L2_SUBJECT_DETAILS$632588
    apex_data_install.load_supporting_object_data(p_table_name => 'L2_SUBJECT_DETAILS', p_delete_after_install => true );
    --L2_TEACHERS: 9/10000 rows exported, APEX$DATA$PKG/L2_TEACHERS$245463
    apex_data_install.load_supporting_object_data(p_table_name => 'L2_TEACHERS', p_delete_after_install => true );
    --L2_TESTS: 4/10000 rows exported, APEX$DATA$PKG/L2_TESTS$711023
    apex_data_install.load_supporting_object_data(p_table_name => 'L2_TESTS', p_delete_after_install => true );
end;