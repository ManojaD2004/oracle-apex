prompt --application/pages/page_00012
begin
--   Manifest
--     PAGE: 00012
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>6454551044931893974
,p_default_application_id=>163721
,p_default_id_offset=>18092864368492973037
,p_default_owner=>'WKSP_INOAUG091DARKMODE'
);
wwv_flow_imp_page.create_page(
 p_id=>12
,p_name=>'NOTES'
,p_alias=>'NOTES'
,p_step_title=>'NOTES'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3511739291715891500)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16088856343201038002)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(16088340207872037945)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(16088919386250038032)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3511739945751891502)
,p_plug_name=>'NOTES'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16088834001391037991)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NOTES_ID,',
'       BRANCH_ID,',
'       NOTES_MESSAGE,',
'       NOTES_DATE,',
'       sys.dbms_lob.getlength(NOTES_DATA) AS DOWNLOAD,',
'       FILE_MIMETYPE,',
'       FILE_CHARSET,',
'       FILE_NAME',
'  from L2_NOTES'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'NOTES'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(3511740110453891502)
,p_name=>'NOTES'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'ARYANCH0804@GMAIL.COM'
,p_internal_uid=>21604604478946864539
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3511741042805891627)
,p_db_column_name=>'NOTES_ID'
,p_display_order=>0
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'Notes ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3511741456678891627)
,p_db_column_name=>'BRANCH_ID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Branch'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_named_lov=>wwv_flow_imp.id(3511740241579891625)
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3511741880331891628)
,p_db_column_name=>'NOTES_MESSAGE'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Notes Message'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3511742320305891628)
,p_db_column_name=>'NOTES_DATE'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Notes Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3490032101644276309)
,p_db_column_name=>'DOWNLOAD'
,p_display_order=>14
,p_column_identifier=>'I'
,p_column_label=>'Download'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'DOWNLOAD:L2_NOTES:NOTES_DATA:NOTES_ID::FILE_MIMETYPE:FILE_NAME:NOTES_DATE:FILE_CHARSET:attachment::'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3511743071194891629)
,p_db_column_name=>'FILE_MIMETYPE'
,p_display_order=>24
,p_column_identifier=>'F'
,p_column_label=>'File Mimetype'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3511743440871891630)
,p_db_column_name=>'FILE_CHARSET'
,p_display_order=>34
,p_column_identifier=>'G'
,p_column_label=>'File Charset'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3511743893552891630)
,p_db_column_name=>'FILE_NAME'
,p_display_order=>44
,p_column_identifier=>'H'
,p_column_label=>'File Name'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(3511714528322159090)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'216045789'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NOTES_ID:BRANCH_ID:NOTES_MESSAGE:NOTES_DATE:DOWNLOAD:FILE_MIMETYPE:FILE_CHARSET:FILE_NAME'
);
wwv_flow_imp.component_end;
end;
/
