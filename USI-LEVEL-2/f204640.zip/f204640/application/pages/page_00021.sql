prompt --application/pages/page_00021
begin
--   Manifest
--     PAGE: 00021
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>6454551044931893974
,p_default_application_id=>163721
,p_default_id_offset=>18092864368492973037
,p_default_owner=>'WKSP_INOAUG091DARKMODE'
);
wwv_flow_imp_page.create_page(
 p_id=>21
,p_name=>'RESET PASSWORD'
,p_alias=>'RESET-PASSWORD1'
,p_step_title=>'RESET PASSWORD'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_overwrite_navigation_list=>'Y'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23309205574187168228)
,p_plug_name=>'RESET ACCOUNT PASSWORD'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(16088843928529037997)
,p_plug_display_sequence=>10
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3515068266293976393)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(23309205574187168228)
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(16088917796646038031)
,p_button_image_alt=>'Submit'
,p_button_position=>'CREATE'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(3515071554103976396)
,p_branch_name=>'GO TO LOGIN PAGE'
,p_branch_action=>'f?p=&APP_ID.:9999:&SESSION.::&DEBUG.:9999::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3490032182113276310)
,p_name=>'P21_T_ID'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(23309205574187168228)
,p_use_cache_before_default=>'NO'
,p_source=>'t_id'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(23309207067590168234)
,p_name=>'P21_USN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(23309205574187168228)
,p_use_cache_before_default=>'NO'
,p_source=>'USN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(23309207653452168240)
,p_name=>'P21_PASSWORD'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(23309205574187168228)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Password'
,p_source=>'PASSWORD'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(16088915285077038030)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(23309207753766168241)
,p_name=>'P21_RE_PASSWORD'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(23309205574187168228)
,p_prompt=>'Re Password'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(16088915285077038030)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(23309207859003168242)
,p_name=>'P21_VC'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(23309205574187168228)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(23309207894407168243)
,p_name=>'P21_VERIFICATION_CODE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(23309205574187168228)
,p_use_cache_before_default=>'NO'
,p_source=>'verification_code'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(3515070776544976396)
,p_validation_name=>'VALID VC'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'l_id varchar2(100);',
'begin ',
'l_id := APP_AUTH_PKG.verify_reset_password(:P21_USN,:P21_VC);',
'if l_id = :P21_USN then',
'return true;',
'else',
'return false;',
'end if;',
'end;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'INVALID VERIFICATION CODE!'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(3515627034745010968)
,p_validation_name=>'SAMEpass'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    IF :P21_PASSWORD = :P21_RE_PASSWORD THEN',
'        RETURN TRUE;',
'    ELSE',
'        RETURN FALSE;',
'    END IF;',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'Passwords do not match!'
,p_associated_item=>wwv_flow_imp.id(23309207753766168241)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3515071046242976396)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'reset'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN ',
'APP_AUTH_PKG.reset_password(:P21_USN,:P21_PASSWORD);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'PASSWORD RESET SUCCESSFUL! PLEASE LOG-IN.'
,p_internal_uid=>21607935414735949433
);
wwv_flow_imp.component_end;
end;
/
