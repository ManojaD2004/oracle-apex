prompt --application/pages/page_00009
begin
--   Manifest
--     PAGE: 00009
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>6454551044931893974
,p_default_application_id=>163721
,p_default_id_offset=>18092864368492973037
,p_default_owner=>'WKSP_INOAUG091DARKMODE'
);
wwv_flow_imp_page.create_page(
 p_id=>9
,p_name=>'Chat'
,p_alias=>'CHAT'
,p_step_title=>'Chat'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* BEGIN comments/chat region styles */',
'.t-Chat .t-Chat--own .t-Comments-icon {',
'  margin-right: 0;',
'  margin-left: 12px;',
'}',
'',
'.t-Chat .t-Chat--own {',
'  flex-direction: row-reverse;',
'}',
'',
'.t-Chat .t-Chat--own .t-Comments-body {',
'  align-items: flex-end;',
'}',
'',
'.t-Chat .t-Chat--own .t-Comments-comment:after {',
'  border-left-color: var(--ut-comment-chat-background-color);',
'  border-right-color: rgba(0,0,0,0);',
'  right: none;',
'  left: 100%;',
'}',
'',
'.t-Chat .t-Comments {',
'   height: 470px;',
'   overflow: scroll;',
'}',
'/* END comments/chat region styles */ '))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(160209534346374233761)
,p_plug_name=>'Chat region'
,p_region_name=>'functional_chat'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(16088843928529037997)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(160209533054677233748)
,p_name=>'Chat messages'
,p_region_name=>'chat-messages'
,p_parent_plug_id=>wwv_flow_imp.id(160209534346374233761)
,p_template=>wwv_flow_imp.id(16088377186786037964)
,p_display_sequence=>10
,p_region_css_classes=>'t-Chat'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Comments--chat'
,p_new_grid_row=>false
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT user_name,',
'       comment_text,',
'       comment_date,',
'       apex_string.get_initials(user_name) user_icon,',
'       null                     AS actions,',
'       null                     AS attribute_1,',
'       null                     AS attribute_2,',
'       null                     AS attribute_3,',
'       null                     AS attribute_4,',
'       CASE ',
'         WHEN user_name = :APP_USER THEN ''t-Chat--own''',
'         ELSE null',
'       END comment_modifiers',
'  FROM chat_messages',
' ORDER BY comment_date ASC;',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(16088873547980038010)
,p_query_num_rows=>10000
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3504521981321666203)
,p_query_column_id=>1
,p_column_alias=>'USER_NAME'
,p_column_display_sequence=>10
,p_column_heading=>'User Name'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3504522396908666204)
,p_query_column_id=>2
,p_column_alias=>'COMMENT_TEXT'
,p_column_display_sequence=>20
,p_column_heading=>'Comment Text'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3504522824139666204)
,p_query_column_id=>3
,p_column_alias=>'COMMENT_DATE'
,p_column_display_sequence=>30
,p_column_heading=>'Comment Date'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3504523209930666204)
,p_query_column_id=>4
,p_column_alias=>'USER_ICON'
,p_column_display_sequence=>40
,p_column_heading=>'User Icon'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3504523536400666205)
,p_query_column_id=>5
,p_column_alias=>'ACTIONS'
,p_column_display_sequence=>50
,p_column_heading=>'Actions'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3504524029876666205)
,p_query_column_id=>6
,p_column_alias=>'ATTRIBUTE_1'
,p_column_display_sequence=>60
,p_column_heading=>'Attribute 1'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3504524363960666205)
,p_query_column_id=>7
,p_column_alias=>'ATTRIBUTE_2'
,p_column_display_sequence=>70
,p_column_heading=>'Attribute 2'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3504524738956666206)
,p_query_column_id=>8
,p_column_alias=>'ATTRIBUTE_3'
,p_column_display_sequence=>80
,p_column_heading=>'Attribute 3'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3504525195826666206)
,p_query_column_id=>9
,p_column_alias=>'ATTRIBUTE_4'
,p_column_display_sequence=>90
,p_column_heading=>'Attribute 4'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3504525582675666206)
,p_query_column_id=>10
,p_column_alias=>'COMMENT_MODIFIERS'
,p_column_display_sequence=>100
,p_column_heading=>'Comment Modifiers'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(160209534449620233762)
,p_plug_name=>'Buttons'
,p_parent_plug_id=>wwv_flow_imp.id(160209534346374233761)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16088377186786037964)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3504526825670666207)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(160209534449620233762)
,p_button_name=>'Send'
,p_button_static_id=>'post-message-btn'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large'
,p_button_template_id=>wwv_flow_imp.id(16088917006354038031)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Send'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-chevron-circle-right'
,p_grid_column_attributes=>'style="align-self: center;"'
,p_grid_column_css_classes=>'col col-2 col-xxs-2 col-xs-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 col-xxl-1 col-end'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>2
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3504525956439666206)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(160209533054677233748)
,p_button_name=>'Reset'
,p_button_static_id=>'reset_chat'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--tiny'
,p_button_template_id=>wwv_flow_imp.id(16088917006354038031)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Reset'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(160209548243524233778)
,p_name=>'P9_MESSAGE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(160209534449620233762)
,p_prompt=>'Message'
,p_placeholder=>'Enter your message...'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_begin_on_new_line=>'N'
,p_colspan=>10
,p_grid_label_column_span=>0
,p_grid_column_css_classes=>'col col-10 col-xxs-10 col-xs-10 col-sm-10 col-md-10 col-lg-10 col-xl-10 col-xxl-11 col-start'
,p_field_template=>wwv_flow_imp.id(16088914917125038029)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(3504527791372666208)
,p_computation_sequence=>10
,p_computation_item=>'P9_MESSAGE'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation_error_message=>'Clear the message if page is refreshed.'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3504528100113666209)
,p_name=>'Post Message on button click'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(3504526825670666207)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'!apex.item("P9_MESSAGE").isEmpty()'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3504528580999666209)
,p_event_id=>wwv_flow_imp.id(3504528100113666209)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
' -- Proceed to insert the message in the table',
' insert into chat_messages (user_name, is_owner, comment_text, comment_date, thread_id)',
'   values (:APP_USER, ''No'', :P9_MESSAGE, sysdate, 1);',
'',
' commit;',
'',
'end;'))
,p_attribute_02=>'P9_MESSAGE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3504529067237666209)
,p_event_id=>wwv_flow_imp.id(3504528100113666209)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.message.showPageSuccess("Message sent.");',
'apex.region("chat-messages").refresh();',
'apex.item("P9_MESSAGE").setValue("");',
'apex.item("P9_MESSAGE").enable();',
'apex.item("P9_MESSAGE").setFocus();',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3504529459737666210)
,p_name=>'Post Message on Enter Key Down'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9_MESSAGE'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'event.key == ''Enter'' && !apex.item("P9_MESSAGE").isEmpty()'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keydown'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3504529975990666210)
,p_event_id=>wwv_flow_imp.id(3504529459737666210)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Trigger button click',
'$("#post-message-btn").click();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3504530415807666210)
,p_name=>'Move refresh button'
,p_event_sequence=>30
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3504530925858666210)
,p_event_id=>wwv_flow_imp.id(3504530415807666210)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$( "#reset_chat" ).appendTo( $( "#functional_chat .t-Region-headerItems.t-Region-headerItems--buttons" ) );',
'function checkNewMessages() {',
'    console.log("Hi");',
'    ',
'  apex.server.process( "CHAT_RELOAD", { x01: "test", pageItems: "#P1_DEPTNO,#P1_EMPNO" },{',
'  success: function( data ) { ',
'    // do something here ',
'    console.log("Success");',
'    console.log(data);',
'    if (data.NEW_MESSAGES_FLAG == ''0'') {',
'        apex.region("chat-messages").refresh();',
'        // apex.event.trigger($("#functional_chat"), "refresh");',
'    }',
'    }, error: function( jqXHR, textStatus, errorThrown ) { ',
'        // handle error ',
'         console.log("Error");',
'         console.log(errorThrown);',
'         console.log(jqXHR);',
'        console.log(textStatus);',
'        } } );',
'}',
'',
'// Set an interval to check for new messages every X seconds (e.g., 5 seconds)',
'setInterval(checkNewMessages, 5000);'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3504531265622666210)
,p_name=>'When Reset button pressed - delete test messages'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(3504525956439666206)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3504531793172666211)
,p_event_id=>wwv_flow_imp.id(3504531265622666210)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'delete from chat_messages where comment_date > to_date(''15082022'',''ddmmyyyy'');'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3504532299551666211)
,p_event_id=>wwv_flow_imp.id(3504531265622666210)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.message.showPageSuccess("Messages were reset.");',
'apex.region("chat-messages").refresh();',
'apex.item("P9_MESSAGE").setValue("");',
'apex.item("P9_MESSAGE").enable();',
'apex.item("P9_MESSAGE").setFocus();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3504532701601666211)
,p_name=>'after Chat refresh - scroll to bottom'
,p_event_sequence=>50
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(160209533054677233748)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3504533200365666211)
,p_event_id=>wwv_flow_imp.id(3504532701601666211)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("#chat-messages .t-Comments").scrollTop($("#chat-messages .t-Comments")[0].scrollHeight);',
''))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3500494690426578903)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CHAT_RELOAD'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
' DECLARE',
'        v_new_messages_count NUMBER;',
'    BEGIN',
'      SELECT COUNT(*)',
'      INTO v_new_messages_count',
'      FROM CHAT_MESSAGES;',
'',
'      IF :CHECK_COUNT IS NULL THEN',
'        :CHECK_COUNT := v_new_messages_count;',
'      END IF;',
'',
'      IF v_new_messages_count = :CHECK_COUNT THEN',
'        :NEW_MESSAGES_FLAG := 1;',
'      ELSE',
'        :NEW_MESSAGES_FLAG := 0;',
'         :CHECK_COUNT := v_new_messages_count;',
'      END IF;',
'           -- Return JSON response',
'  APEX_JSON.open_object;',
'  APEX_JSON.write(''NEW_MESSAGES_FLAG'', :NEW_MESSAGES_FLAG);',
'  APEX_JSON.close_object;',
'    END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>21593359058919551940
);
wwv_flow_imp.component_end;
end;
/
