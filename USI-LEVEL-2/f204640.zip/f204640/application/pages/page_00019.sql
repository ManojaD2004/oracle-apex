prompt --application/pages/page_00019
begin
--   Manifest
--     PAGE: 00019
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>6454551044931893974
,p_default_application_id=>163721
,p_default_id_offset=>18092864368492973037
,p_default_owner=>'WKSP_INOAUG091DARKMODE'
);
wwv_flow_imp_page.create_page(
 p_id=>19
,p_name=>'CHATBOT'
,p_alias=>'CHATBOT'
,p_step_title=>'CHATBOT'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3490032295109276311)
,p_plug_name=>'BOT'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(16088843928529037997)
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_location=>null
,p_required_patch=>wwv_flow_imp.id(16088339622996037944)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3515589985316006877)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16088856343201038002)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(16088340207872037945)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(16088919386250038032)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6228110136240874866)
,p_plug_name=>'OCI_AI'
,p_title=>'OCI AI ChatBot'
,p_region_name=>'inline-assist'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(16088843928529037997)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3515626702007010964)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(3490032295109276311)
,p_button_name=>'SEND'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(16088917796646038031)
,p_button_image_alt=>'Send'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(3515626988737010967)
,p_branch_name=>'GO TO'
,p_branch_action=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3490032338818276312)
,p_name=>'P19_MESSAGE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(3490032295109276311)
,p_prompt=>'Message'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(16088915285077038030)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3515626773027010965)
,p_name=>'P19_RESPONSE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(3490032295109276311)
,p_prompt=>'Response'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(16088915285077038030)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6228110017811874864)
,p_name=>'P19_DETAILS1'
,p_item_sequence=>20
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'''USN : '' || USN || chr(18) || chr(13)||',
'''EMAIL ID : ''|| EMAIL_ID ||chr(10) || chr(13)||',
'''STUDENT NAME : ''|| STD_NAME ||chr(10) || chr(13)||',
'''SEMESTER : ''|| SEM ||chr(10) || chr(13)||',
'''SECTION :  ''|| SECTION || chr(10) ||chr(13) ||',
'''AGE : ''|| AGE || chr(10) ||chr(13)||',
'''BRANCH ID : ''|| BRANCH_ID || chr(10) ||chr(13)||',
'''GENDER: ''|| GENDER || chr(10) || chr(13)',
'as prompt_context',
'FROM L2_STUDENTS',
'WHERE EMAIL_ID = LOWER(:APP_USER);'))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6228110398421874868)
,p_name=>'P19_DETAILS2'
,p_item_sequence=>30
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    (''ANNOUNCEMENT_ID : '' || ROW1.ANNOUNCEMENT_ID || '' '' || chr(18) || chr(13) || ',
'     ''BRANCH_ID : '' || ROW1.BRANCH_ID || '' '' || chr(10) || chr(13) ||',
'     ''ANNOUNCEMENT_MESSAGE : ''  || ROW1.ANNOUNCEMENT_MESSAGE || '' '' || chr(10) || chr(13) ||',
'     ''ANNOUN_DATE : '' || ROW1.ANNOUN_DATE || chr(10) || chr(13)) AS ANNOUNCE ',
'FROM ',
'    L2_ANNOUNCEMENT ROW1;',
''))
,p_item_default_type=>'SQL_QUERY_COLON'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6228110597822874870)
,p_name=>'P19_DETAILS3'
,p_item_sequence=>40
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    ''USN: '' || X.USN || CHR(18) || CHR(13) ||',
'    ''SUBJECT_ID: '' || X.SUBJECT_ID || CHR(10) || CHR(13) ||',
'    ''TEST_ID: '' || Y.TEST_ID || CHR(10) || CHR(13) ||',
'    ''TEST_CODE: '' || Y.TEST_CODE || CHR(10) || CHR(13) ||',
'    ''TEST_NAME: '' || Y.TEST_NAME || CHR(10) || CHR(13) ||',
'    ''TEST_DATE: '' || Y.TEST_DATE || CHR(10) || CHR(13) ||',
'    ''MARKS: '' || YY.MARKS || CHR(10) || CHR(13) ||',
'    ''TOTAL_MARKS: '' || Y.TOTAL_MARKS || CHR(10) || CHR(13) ||',
'    ''BRANCH_ID: '' || Z.BRANCH_ID || CHR(10) || CHR(13) ||',
'    ''T_INCHARGE_ID: '' || Z.T_INCHARGE_ID || CHR(10) || CHR(13) ||',
'    ''TOTAL_CLASS: '' || Z.TOTAL_CLASS || CHR(10) || CHR(13) ||',
'    ''SUBJECT_CODE: '' || Z.SUBJECT_CODE || CHR(10) || CHR(13) ||',
'    ''SUBJECT_NAME: '' || ZZ.SUBJECT_NAME || CHR(10) || CHR(13) AS TEST_DETAILS_OF_STUDENT',
'FROM',
'    L2_STUDENTS_SUBJECTS X,',
'    L2_TESTS             Y,',
'    L2_STUDENTS_MARKS    YY,',
'    L2_SUBJECTS          Z,',
'    L2_SUBJECT_DETAILS   ZZ',
'WHERE',
'    X.SUBJECT_ID = Y.SUBJECT_ID',
'    AND Y.SUBJECT_ID = Z.SUBJECT_ID ',
'    AND Y.TEST_ID = YY.TEST_ID',
'    AND Z.SUBJECT_CODE = ZZ.SUBJECT_CODE',
'    AND YY.USN IN (SELECT USN FROM L2_STUDENTS WHERE EMAIL_ID = LOWER(:APP_USER))',
'    AND X.USN IN (SELECT USN FROM L2_STUDENTS WHERE EMAIL_ID = LOWER(:APP_USER))',
'ORDER BY X.SUBJECT_ID, Y.TEST_CODE;'))
,p_item_default_type=>'SQL_QUERY_COLON'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6286576652430190864)
,p_name=>'P19_DETAILS4'
,p_item_sequence=>50
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    ''SUBJECT_ID: '' || X.SUBJECT_ID || CHR(18) || CHR(13) ||',
'    ''USN: '' || X.USN || CHR(10) || CHR(13) ||',
'    ''BRANCH_ID: '' || Y.BRANCH_ID || CHR(10) || CHR(13) ||',
'    ''SUBJECT_CODE: '' || Y.SUBJECT_CODE || CHR(10) || CHR(13) ||',
'    ''SUBJECT_NAME: '' || YY.SUBJECT_NAME || CHR(10) || CHR(13) ||',
'    ''CLASS_ID: '' || Z.CLASS_ID || CHR(10) || CHR(13) ||',
'    ''CLASS_NO: '' || Z.CLASS_NO || CHR(10) || CHR(13) ||',
'    ''CLASS_DATE: '' || Z.CLASS_DATE || CHR(10) || CHR(13) ||',
'    ''ATTENDS: '' || ',
'        CASE',
'            WHEN ZZ.ATTENDANCE = ''Y'' THEN ''PRESENT''',
'            ELSE ''ABSENT''',
'        END || CHR(10) || CHR(13) AS STUDENT_ATTENDANCE_DETAILS',
'FROM',
'    L2_STUDENTS_SUBJECTS X,',
'    L2_SUBJECTS          Y,',
'    L2_SUBJECT_DETAILS   YY,',
'    L2_CLASSES           Z,',
'    L2_STUDENTS_ATTEND   ZZ',
'WHERE',
'    X.SUBJECT_ID = Y.SUBJECT_ID',
'    AND Y.SUBJECT_CODE = YY.SUBJECT_CODE',
'    AND Y.SUBJECT_ID = Z.SUBJECT_ID',
'    AND Z.CLASS_ID = ZZ.CLASS_ID',
'    AND X.USN IN (SELECT USN FROM L2_STUDENTS WHERE EMAIL_ID = LOWER(:APP_USER))',
'    AND ZZ.USN IN (SELECT USN FROM L2_STUDENTS WHERE EMAIL_ID = LOWER(:APP_USER))',
'ORDER BY',
'    X.SUBJECT_ID,',
'    Z.CLASS_NO;',
'    ',
''))
,p_item_default_type=>'SQL_QUERY_COLON'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(3515627160425010969)
,p_computation_sequence=>10
,p_computation_item=>'P19_DETAILS1'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'''USN : '' || USN || chr(18) || chr(13)||',
'''EMAIL ID : ''|| EMAIL_ID ||chr(10) || chr(13)||',
'''STUDENT NAME : ''|| STD_NAME ||chr(10) || chr(13)||',
'''SEMESTER : ''|| SEM ||chr(10) || chr(13)||',
'''SECTION :  ''|| SECTION || chr(10) ||chr(13) ||',
'''AGE : ''|| AGE || chr(10) ||chr(13)||',
'''BRANCH ID : ''|| BRANCH_ID || chr(10) ||chr(13)||',
'''GENDER: ''|| GENDER || chr(10) || chr(13)',
'as prompt_context',
'FROM L2_STUDENTS',
'WHERE EMAIL_ID = LOWER(:APP_USER);'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(6228110322724874867)
,p_computation_sequence=>20
,p_computation_item=>'P19_DETAILS2'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY_COLON'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    (''ANNOUNCEMENT_ID : '' || ROW1.ANNOUNCEMENT_ID || '' '' || chr(18) || chr(13) || ',
'     ''BRANCH_ID : '' || ROW1.BRANCH_ID || '' '' || chr(10) || chr(13) ||',
'     ''ANNOUNCEMENT_MESSAGE : ''  || ROW1.ANNOUNCEMENT_MESSAGE || '' '' || chr(10) || chr(13) ||',
'     ''ANNOUN_DATE : '' || ROW1.ANNOUN_DATE || chr(10) || chr(13)) AS ANNOUNCE ',
'FROM ',
'    L2_ANNOUNCEMENT ROW1;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(6228110436194874869)
,p_computation_sequence=>30
,p_computation_item=>'P19_DETAILS3'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY_COLON'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    ''USN: '' || X.USN || CHR(18) || CHR(13) ||',
'    ''SUBJECT_ID: '' || X.SUBJECT_ID || CHR(10) || CHR(13) ||',
'    ''TEST_ID: '' || Y.TEST_ID || CHR(10) || CHR(13) ||',
'    ''TEST_CODE: '' || Y.TEST_CODE || CHR(10) || CHR(13) ||',
'    ''TEST_NAME: '' || Y.TEST_NAME || CHR(10) || CHR(13) ||',
'    ''TEST_DATE: '' || Y.TEST_DATE || CHR(10) || CHR(13) ||',
'    ''MARKS: '' || YY.MARKS || CHR(10) || CHR(13) ||',
'    ''TOTAL_MARKS: '' || Y.TOTAL_MARKS || CHR(10) || CHR(13) ||',
'    ''BRANCH_ID: '' || Z.BRANCH_ID || CHR(10) || CHR(13) ||',
'    ''T_INCHARGE_ID: '' || Z.T_INCHARGE_ID || CHR(10) || CHR(13) ||',
'    ''TOTAL_CLASS: '' || Z.TOTAL_CLASS || CHR(10) || CHR(13) ||',
'    ''SUBJECT_CODE: '' || Z.SUBJECT_CODE || CHR(10) || CHR(13) ||',
'    ''SUBJECT_NAME: '' || ZZ.SUBJECT_NAME || CHR(10) || CHR(13) AS TEST_DETAILS_OF_STUDENT',
'FROM',
'    L2_STUDENTS_SUBJECTS X,',
'    L2_TESTS             Y,',
'    L2_STUDENTS_MARKS    YY,',
'    L2_SUBJECTS          Z,',
'    L2_SUBJECT_DETAILS   ZZ',
'WHERE',
'    X.SUBJECT_ID = Y.SUBJECT_ID',
'    AND Y.SUBJECT_ID = Z.SUBJECT_ID ',
'    AND Y.TEST_ID = YY.TEST_ID',
'    AND Z.SUBJECT_CODE = ZZ.SUBJECT_CODE',
'    AND YY.USN IN (SELECT USN FROM L2_STUDENTS WHERE EMAIL_ID = LOWER(:APP_USER))',
'    AND X.USN IN (SELECT USN FROM L2_STUDENTS WHERE EMAIL_ID = LOWER(:APP_USER))',
'ORDER BY X.SUBJECT_ID, Y.TEST_CODE;'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(6270727821449709113)
,p_computation_sequence=>40
,p_computation_item=>'P19_DETAILS4'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY_COLON'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    ''SUBJECT_ID: '' || X.SUBJECT_ID || CHR(18) || CHR(13) ||',
'    ''USN: '' || X.USN || CHR(10) || CHR(13) ||',
'    ''BRANCH_ID: '' || Y.BRANCH_ID || CHR(10) || CHR(13) ||',
'    ''SUBJECT_CODE: '' || Y.SUBJECT_CODE || CHR(10) || CHR(13) ||',
'    ''SUBJECT_NAME: '' || YY.SUBJECT_NAME || CHR(10) || CHR(13) ||',
'    ''CLASS_ID: '' || Z.CLASS_ID || CHR(10) || CHR(13) ||',
'    ''CLASS_NO: '' || Z.CLASS_NO || CHR(10) || CHR(13) ||',
'    ''CLASS_DATE: '' || Z.CLASS_DATE || CHR(10) || CHR(13) ||',
'    ''ATTENDS: '' || ',
'        CASE',
'            WHEN ZZ.ATTENDANCE = ''Y'' THEN ''PRESENT''',
'            ELSE ''ABSENT''',
'        END || CHR(10) || CHR(13) AS STUDENT_ATTENDANCE_DETAILS',
'FROM',
'    L2_STUDENTS_SUBJECTS X,',
'    L2_SUBJECTS          Y,',
'    L2_SUBJECT_DETAILS   YY,',
'    L2_CLASSES           Z,',
'    L2_STUDENTS_ATTEND   ZZ',
'WHERE',
'    X.SUBJECT_ID = Y.SUBJECT_ID',
'    AND Y.SUBJECT_CODE = YY.SUBJECT_CODE',
'    AND Y.SUBJECT_ID = Z.SUBJECT_ID',
'    AND Z.CLASS_ID = ZZ.CLASS_ID',
'    AND X.USN IN (SELECT USN FROM L2_STUDENTS WHERE EMAIL_ID = LOWER(:APP_USER))',
'    AND ZZ.USN IN (SELECT USN FROM L2_STUDENTS WHERE EMAIL_ID = LOWER(:APP_USER))',
'ORDER BY',
'    X.SUBJECT_ID,',
'    Z.CLASS_NO;',
'    ',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(5862247577724056266)
,p_name=>'AI_CHAT'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5862247713558056267)
,p_event_id=>wwv_flow_imp.id(5862247577724056266)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_AI_ASSISTANT'
,p_attribute_01=>'INLINE'
,p_attribute_03=>'#inline-assist'
,p_ai_remote_server_id=>wwv_flow_imp.id(6222241933456706523)
,p_ai_system_prompt=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Use the instructions below to answer the questions. Do not answer any other question that is out of this app''s context and not in the instructions given below.',
'',
'&P19_DETAILS1.',
'&P19_DETAILS2.',
'&P19_DETAILS3.',
'&P19_DETAILS4.'))
,p_ai_welcome_message=>'Hello, how can I help you?'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3515626906972010966)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'callNodeServer'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_url           VARCHAR2(4000) := ''https://usi-production.up.railway.app/get-role''; -- Replace with your Render app URL',
'    l_response      CLOB;',
'    l_usn VARCHAR2(100);',
'    l_user_email    VARCHAR2(100) := LOWER(:APP_USER); -- Automatically provided by APEX',
'    l_message       VARCHAR2(4000) := :P19_MESSAGE; -- Page item where the user types their message',
'    l_body          CLOB;',
'BEGIN',
'    -- Prepare JSON body',
'    SELECT USN INTO l_usn FROM L2_STUDENTS WHERE EMAIL_ID = LOWER(:APP_USER);',
'    l_body := ''{"userEmail": "'' || l_usn || ''", "message": "'' || l_message || ''"}'';',
'',
'    -- Set request headers',
'    APEX_WEB_SERVICE.SET_REQUEST_HEADERS(',
'        p_name_01  => ''Content-Type'', p_value_01 => ''application/json''',
'    );',
'',
'    -- Make the REST request',
'    l_response := APEX_WEB_SERVICE.MAKE_REST_REQUEST(',
'        p_url            => l_url,',
'        p_http_method    => ''POST'',',
'        p_body           => l_body',
'    );',
'',
'    -- Parse the JSON response',
'    BEGIN',
'        -- Parse the response using APEX_JSON',
'        APEX_JSON.parse(l_response);',
'',
'        -- Get the response message from the JSON',
'        :P19_RESPONSE := APEX_JSON.get_varchar2(p_path => ''response'');',
'    EXCEPTION',
'        WHEN OTHERS THEN',
'            -- If there''s an error parsing the JSON, show the error message',
'            :P19_RESPONSE := ''Error parsing JSON response: '' || SQLERRM;',
'    END;',
'',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        :P19_RESPONSE := ''An error occurred: '' || SQLERRM;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_required_patch=>wwv_flow_imp.id(16088339622996037944)
,p_internal_uid=>21608491275464984003
);
wwv_flow_imp.component_end;
end;
/
