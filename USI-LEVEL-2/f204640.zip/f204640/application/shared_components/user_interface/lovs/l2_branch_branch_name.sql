prompt --application/shared_components/user_interface/lovs/l2_branch_branch_name
begin
--   Manifest
--     L2_BRANCH.BRANCH_NAME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>6454551044931893974
,p_default_application_id=>163721
,p_default_id_offset=>18092864368492973037
,p_default_owner=>'WKSP_INOAUG091DARKMODE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(3511740241579891625)
,p_lov_name=>'L2_BRANCH.BRANCH_NAME'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'L2_BRANCH'
,p_return_column_name=>'BRANCH_ID'
,p_display_column_name=>'BRANCH_NAME'
,p_default_sort_column_name=>'BRANCH_NAME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>15550530765630
);
wwv_flow_imp.component_end;
end;
/
