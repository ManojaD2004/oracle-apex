prompt --application/shared_components/user_interface/lovs/l2_students_email_id
begin
--   Manifest
--     L2_STUDENTS.EMAIL_ID
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>6454551044931893974
,p_default_application_id=>163721
,p_default_id_offset=>18092864368492973037
,p_default_owner=>'WKSP_INOAUG091DARKMODE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(6253707916546197109)
,p_lov_name=>'L2_STUDENTS.EMAIL_ID'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'L2_STUDENTS'
,p_return_column_name=>'USN'
,p_display_column_name=>'EMAIL_ID'
,p_default_sort_column_name=>'EMAIL_ID'
,p_default_sort_direction=>'ASC'
,p_version_scn=>15552879251193
);
wwv_flow_imp.component_end;
end;
/
