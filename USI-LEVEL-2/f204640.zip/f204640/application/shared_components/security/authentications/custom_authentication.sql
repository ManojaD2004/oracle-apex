prompt --application/shared_components/security/authentications/custom_authentication
begin
--   Manifest
--     AUTHENTICATION: CUSTOM AUTHENTICATION
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>6454551044931893974
,p_default_application_id=>163721
,p_default_id_offset=>18092864368492973037
,p_default_owner=>'WKSP_INOAUG091DARKMODE'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(16181383994057335241)
,p_name=>'CUSTOM AUTHENTICATION'
,p_scheme_type=>'NATIVE_CUSTOM'
,p_attribute_03=>'APP_AUTH_PKG.custom_authenticate'
,p_attribute_05=>'N'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
,p_version_scn=>15546292569260
);
wwv_flow_imp.component_end;
end;
/
