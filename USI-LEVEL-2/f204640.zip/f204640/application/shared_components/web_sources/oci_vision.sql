prompt --application/shared_components/web_sources/oci_vision
begin
--   Manifest
--     WEB SOURCE: OCI_VISION
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>6454551044931893974
,p_default_application_id=>163721
,p_default_id_offset=>18092864368492973037
,p_default_owner=>'WKSP_INOAUG091DARKMODE'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(6281884353379229464)
,p_name=>'OCI_VISION'
,p_static_id=>'oci_vision'
,p_web_source_type=>'NATIVE_OCI'
,p_data_profile_id=>wwv_flow_imp.id(6281883266830229461)
,p_remote_server_id=>wwv_flow_imp.id(6214336172719719770)
,p_url_path_prefix=>'/analyzeImage'
,p_credential_id=>wwv_flow_imp.id(6211152620851625641)
,p_version_scn=>15552913324116
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(6281884708245229465)
,p_web_src_module_id=>wwv_flow_imp.id(6281884353379229464)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(6281885049830229466)
,p_web_src_module_id=>wwv_flow_imp.id(6281884353379229464)
,p_operation=>'POST'
,p_url_pattern=>'.'
,p_request_body_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'   "compartmentId": "#COMPARTMENT_ID#",',
'   "image": {',
'      "source": "INLINE",',
'      "data": "#FILE_DATA#"',
'   },',
'   "features": [',
'      {',
'         "featureType": "#FEATURE_TYPE#",',
'         "maxResults": 5',
'      }',
'   ]',
'}'))
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(6281885462075229466)
,p_web_src_module_id=>wwv_flow_imp.id(6281884353379229464)
,p_web_src_operation_id=>wwv_flow_imp.id(6281885049830229466)
,p_name=>'COMPARTMENT_ID'
,p_param_type=>'BODY'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(6281885976362229467)
,p_web_src_module_id=>wwv_flow_imp.id(6281884353379229464)
,p_web_src_operation_id=>wwv_flow_imp.id(6281885049830229466)
,p_name=>'FILE_DATA'
,p_param_type=>'BODY'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(6281886506334229467)
,p_web_src_module_id=>wwv_flow_imp.id(6281884353379229464)
,p_web_src_operation_id=>wwv_flow_imp.id(6281885049830229466)
,p_name=>'FEATURE_TYPE'
,p_param_type=>'BODY'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(6281886980489229467)
,p_web_src_module_id=>wwv_flow_imp.id(6281884353379229464)
,p_web_src_operation_id=>wwv_flow_imp.id(6281885049830229466)
,p_name=>'RESPONSE'
,p_param_type=>'BODY'
,p_is_required=>false
,p_direction=>'OUT'
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(6281887441831229468)
,p_web_src_module_id=>wwv_flow_imp.id(6281884353379229464)
,p_web_src_operation_id=>wwv_flow_imp.id(6281885049830229466)
,p_name=>'Content-Type'
,p_param_type=>'HEADER'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value=>'application/json'
,p_is_static=>true
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(6281887993985229468)
,p_web_src_module_id=>wwv_flow_imp.id(6281884353379229464)
,p_operation=>'PUT'
,p_database_operation=>'UPDATE'
,p_url_pattern=>'/:id'
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(6281888340642229468)
,p_web_src_module_id=>wwv_flow_imp.id(6281884353379229464)
,p_operation=>'DELETE'
,p_database_operation=>'DELETE'
,p_url_pattern=>'/:id'
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
