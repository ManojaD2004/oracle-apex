prompt --application/shared_components/logic/application_items/new_messages_flag
begin
--   Manifest
--     APPLICATION ITEM: NEW_MESSAGES_FLAG
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>6454551044931893974
,p_default_application_id=>163721
,p_default_id_offset=>18092864368492973037
,p_default_owner=>'WKSP_INOAUG091DARKMODE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(5809330729093599526)
,p_name=>'NEW_MESSAGES_FLAG'
,p_scope=>'GLOBAL'
,p_protection_level=>'I'
,p_version_scn=>15552314301457
);
wwv_flow_imp.component_end;
end;
/
