prompt --workspace/remote_servers/oci_chat
begin
--   Manifest
--     REMOTE SERVER: OCI_CHAT
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>6454551044931893974
,p_default_application_id=>163721
,p_default_id_offset=>18092864368492973037
,p_default_owner=>'WKSP_INOAUG091DARKMODE'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(6222241933456706523)
,p_name=>'OCI_CHAT'
,p_static_id=>'oci_chat'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('oci_chat'),'https://inference.generativeai.us-chicago-1.oci.oraclecloud.com')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('oci_chat'),'')
,p_server_type=>'GENERATIVE_AI'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('oci_chat'),'')
,p_credential_id=>wwv_flow_imp.id(6211152620851625641)
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('oci_chat'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('oci_chat'),'')
,p_prompt_on_install=>true
,p_ai_provider_type=>'OCI_GENAI'
,p_ai_is_builder_service=>false
,p_ai_model_name=>nvl(wwv_flow_application_install.get_remote_server_ai_model('oci_chat'),'')
,p_ai_http_headers=>nvl(wwv_flow_application_install.get_remote_server_ai_headers('oci_chat'),'')
,p_ai_attributes=>nvl(wwv_flow_application_install.get_remote_server_ai_attrs('oci_chat'),'{"compartmentId":"ocid1.compartment.oc1..aaaaaaaa6zowrkkrrnnf5wqzwipmry7dflx2dltxstgbow3ydgzm74xic4fa","servingMode":{"modelId":"cohere.command-r-16k","servingType":"ON_DEMAND"}}')
);
wwv_flow_imp.component_end;
end;
/
