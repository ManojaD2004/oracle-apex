prompt --application/pages/page_00024
begin
--   Manifest
--     PAGE: 00024
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>6454551044931893974
,p_default_application_id=>193996
,p_default_id_offset=>18092960892506985398
,p_default_owner=>'WKSP_INOAUG091DARKMODE'
);
wwv_flow_imp_page.create_page(
 p_id=>24
,p_name=>'AI Output Test'
,p_alias=>'AI-OUTPUT-TEST'
,p_step_title=>'AI Output Test'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30665417976382229163)
,p_plug_name=>'List Images'
,p_title=>'List Images'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16167711835329120490)
,p_plug_display_sequence=>50
,p_query_type=>'TABLE'
,p_query_table=>'L2_IMAGE_TEST_STUDENTS'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'List Images'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(30665418072435229164)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MANOJADKC2004@GMAIL.COM'
,p_internal_uid=>48758378964942214562
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(30665418142334229165)
,p_db_column_name=>'IMAGE_ID'
,p_display_order=>10
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'Image Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(30665418266712229166)
,p_db_column_name=>'USN'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Usn'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(30665418394397229167)
,p_db_column_name=>'STUDENT_NAME'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Student Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(30665418512493229168)
,p_db_column_name=>'BRANCH_ID'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Branch Id'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(30665418564341229169)
,p_db_column_name=>'IMAGE_DATA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Image Data'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_heading_alignment=>'LEFT'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
,p_required_patch=>wwv_flow_imp.id(16167617495353120450)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(30665418681308229170)
,p_db_column_name=>'FILE_MIMETYPE'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'File Mimetype'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(30665418753753229171)
,p_db_column_name=>'FILE_CHARSET'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'File Charset'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(30665418841067229172)
,p_db_column_name=>'FILE_NAME'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'File Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(30665418971530229173)
,p_db_column_name=>'AI_OUTPUT'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Ai Output'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_required_patch=>wwv_flow_imp.id(16167617495353120450)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6286480340499178505)
,p_db_column_name=>'X1'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'X1'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6286480462340178506)
,p_db_column_name=>'Y1'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Y1'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6286480598736178507)
,p_db_column_name=>'X2'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'X2'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6286480654165178508)
,p_db_column_name=>'Y2'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Y2'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6286480781897178509)
,p_db_column_name=>'X3'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'X3'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6286480807638178510)
,p_db_column_name=>'Y3'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Y3'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6286480997197178511)
,p_db_column_name=>'X0'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'X0'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6286481045362178512)
,p_db_column_name=>'Y0'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Y0'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(30675164553500670138)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'243733377'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'IMAGE_ID:USN:STUDENT_NAME:BRANCH_ID:IMAGE_DATA:FILE_MIMETYPE:FILE_CHARSET:FILE_NAME:AI_OUTPUT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30673461610130303466)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16167734083956120499)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(16167618037682120450)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(16167796800214120528)
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6301827676666547028)
,p_button_sequence=>40
,p_button_name=>'Process'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(16167795204145120528)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Process AI'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6286480214483178504)
,p_name=>'P24_FEATURE_TYPE'
,p_item_sequence=>30
,p_item_default=>'FACE_DETECTION'
,p_prompt=>'FEATURE_TYPE'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>'STATIC:IMAGE_CLASSIFICATION;IMAGE_CLASSIFICATION,OBJECT_DETECTION;OBJECT_DETECTION,TEXT_DETECTION;TEXT_DETECTION,FACE_DETECTION;FACE_DETECTION,FACE_EMBEDDING;FACE_EMBEDDING'
,p_field_template=>wwv_flow_imp.id(16167792785719120526)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30665422494703229173)
,p_name=>'P24_IMAGE_ID'
,p_item_sequence=>20
,p_prompt=>'IMAGE_ID'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>'SELECT IMAGE_ID FROM L2_IMAGE_TEST_STUDENTS;'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(16167792785719120526)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'CONTAINS_IGNORE'
,p_attribute_04=>'Y'
,p_attribute_05=>'7'
,p_attribute_09=>'1'
,p_attribute_10=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30665422656312229175)
,p_name=>'P24_RESPONSE'
,p_item_sequence=>10
,p_prompt=>'Response'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(16167792785719120526)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(6301833080045547044)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'AI OutPut'
,p_attribute_01=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>24394793972552532442
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(6301833437910547044)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(6301833080045547044)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Call OCI Service'
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(6214240942352707410)
,p_web_src_operation_id=>wwv_flow_imp.id(6214241596625707411)
,p_attribute_01=>'WEB_SOURCE'
,p_internal_uid=>24394794330417532442
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(6301833918573547046)
,p_page_id=>24
,p_web_src_param_id=>wwv_flow_imp.id(6263986402503302296)
,p_page_process_id=>wwv_flow_imp.id(6301833437910547044)
,p_value_type=>'STATIC'
,p_value=>'ocid1.compartment.oc1..aaaaaaaa6zowrkkrrnnf5wqzwipmry7dflx2dltxstgbow3ydgzm74xic4fa'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(6301834466452547046)
,p_page_id=>24
,p_web_src_param_id=>wwv_flow_imp.id(6263987364151302297)
,p_page_process_id=>wwv_flow_imp.id(6301833437910547044)
,p_value_type=>'SQL_QUERY'
,p_value=>'SELECT :P24_FEATURE_TYPE FROM DUAL;'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(6301834924521547047)
,p_page_id=>24
,p_web_src_param_id=>wwv_flow_imp.id(6263986810541302297)
,p_page_process_id=>wwv_flow_imp.id(6301833437910547044)
,p_value_type=>'SQL_QUERY'
,p_value=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    REPLACE(REPLACE(APEX_WEB_SERVICE.BLOB2CLOBBASE64(IMAGE_DATA),',
'                    CHR(10),',
'                    ''''),',
'            CHR(13),',
'            '''') AS FILE_DATA',
'FROM',
'    L2_IMAGE_TEST_STUDENTS',
'WHERE IMAGE_ID = :P24_IMAGE_ID;'))
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(6301835442200547047)
,p_page_id=>24
,p_web_src_param_id=>wwv_flow_imp.id(6264953667292310276)
,p_page_process_id=>wwv_flow_imp.id(6301833437910547044)
,p_value_type=>'ITEM'
,p_value=>'P24_RESPONSE'
,p_ignore_output=>false
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(6301835824016547048)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(6301833080045547044)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Parse Output'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    VX1          NUMBER;',
'    VY1          NUMBER;',
'BEGIN',
'    BEGIN',
'        DBMS_OUTPUT.PUT_LINE(''0'');',
'        SELECT',
'            X,',
'            Y INTO VX1,',
'            VY1',
'        FROM',
'            JSON_TABLE(:P24_RESPONSE,',
'            ''$.detectedFaces[0].boundingPolygon.normalizedVertices[0]'' COLUMNS ( X NUMBER PATH ''$.x'',',
'            Y NUMBER PATH ''$.y'' ) );',
'        DBMS_OUTPUT.PUT_LINE(''x1: ''',
'                             || VX1',
'                             || '', y1: ''',
'                             || VY1);',
'        UPDATE L2_IMAGE_TEST_STUDENTS',
'        SET',
'            X0 = VX1,',
'            Y0 = VY1 WHERE IMAGE_ID = :P24_IMAGE_ID;',
'    EXCEPTION',
'        WHEN OTHERS THEN',
'            DBMS_OUTPUT.PUT_LINE(''Error processing vertex 0: ''',
'                                 || SQLERRM);',
'    END;',
'    BEGIN',
'        DBMS_OUTPUT.PUT_LINE(''1'');',
'        SELECT',
'            X,',
'            Y INTO VX1,',
'            VY1',
'        FROM',
'            JSON_TABLE(:P24_RESPONSE,',
'            ''$.detectedFaces[0].boundingPolygon.normalizedVertices[1]'' COLUMNS ( X NUMBER PATH ''$.x'',',
'            Y NUMBER PATH ''$.y'' ) );',
'        DBMS_OUTPUT.PUT_LINE(''x1: ''',
'                             || VX1',
'                             || '', y1: ''',
'                             || VY1);',
'        UPDATE L2_IMAGE_TEST_STUDENTS',
'        SET',
'            X1 = VX1,',
'            Y1 = VY1 WHERE IMAGE_ID = :P24_IMAGE_ID;',
'    EXCEPTION',
'        WHEN OTHERS THEN',
'            DBMS_OUTPUT.PUT_LINE(''Error processing vertex 1: ''',
'                                 || SQLERRM);',
'    END;',
'    BEGIN',
'        DBMS_OUTPUT.PUT_LINE(''2'');',
'        SELECT',
'            X,',
'            Y INTO VX1,',
'            VY1',
'        FROM',
'            JSON_TABLE(:P24_RESPONSE,',
'            ''$.detectedFaces[0].boundingPolygon.normalizedVertices[2]'' COLUMNS ( X NUMBER PATH ''$.x'',',
'            Y NUMBER PATH ''$.y'' ) );',
'        DBMS_OUTPUT.PUT_LINE(''x1: ''',
'                             || VX1',
'                             || '', y1: ''',
'                             || VY1);',
'        UPDATE L2_IMAGE_TEST_STUDENTS',
'        SET',
'            X2 = VX1,',
'            Y2 = VY1 WHERE IMAGE_ID = :P24_IMAGE_ID;',
'    EXCEPTION',
'        WHEN OTHERS THEN',
'            DBMS_OUTPUT.PUT_LINE(''Error processing vertex 2: ''',
'                                 || SQLERRM);',
'    END;',
'    BEGIN',
'        DBMS_OUTPUT.PUT_LINE(''3'');',
'        SELECT',
'            X,',
'            Y INTO VX1,',
'            VY1',
'        FROM',
'            JSON_TABLE(:P24_RESPONSE,',
'            ''$.detectedFaces[0].boundingPolygon.normalizedVertices[3]'' COLUMNS ( X NUMBER PATH ''$.x'',',
'            Y NUMBER PATH ''$.y'' ) );',
'        DBMS_OUTPUT.PUT_LINE(''x1: ''',
'                             || VX1',
'                             || '', y1: ''',
'                             || VY1);',
'        UPDATE L2_IMAGE_TEST_STUDENTS',
'        SET',
'            X3 = VX1,',
'            Y3 = VY1 WHERE IMAGE_ID = :P24_IMAGE_ID;',
'    EXCEPTION',
'        WHEN OTHERS THEN',
'            DBMS_OUTPUT.PUT_LINE(''Error processing vertex 3: ''',
'                                 || SQLERRM);',
'    END;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>24394796716523532446
);
wwv_flow_imp.component_end;
end;
/
