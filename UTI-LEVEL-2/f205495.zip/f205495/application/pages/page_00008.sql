prompt --application/pages/page_00008
begin
--   Manifest
--     PAGE: 00008
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>6454551044931893974
,p_default_application_id=>193996
,p_default_id_offset=>18092960892506985398
,p_default_owner=>'WKSP_INOAUG091DARKMODE'
);
wwv_flow_imp_page.create_page(
 p_id=>8
,p_name=>'Create Classes'
,p_alias=>'CREATE-CLASSES'
,p_step_title=>'Create Classes For Attendance'
,p_allow_duplicate_submissions=>'N'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Scroll Results Only in Side Column */',
'.t-Body-side {',
'    display: flex;',
'    flex-direction: column;',
'    overflow: hidden;',
'}',
'.search-results {',
'    flex: 1;',
'    overflow: auto;',
'}',
'/* Format Search Region */',
'.search-region {',
'    border-bottom: 1px solid rgba(0,0,0,.1);',
'    flex-shrink: 0;',
'}'))
,p_step_template=>wwv_flow_imp.id(16167622059619120453)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3468912567247748775)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16167734083956120499)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(16167618037682120450)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(16167796800214120528)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3468914078500748777)
,p_plug_name=>'Search'
,p_region_css_classes=>'search-region padding-md'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(16167655060117120468)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(3468914851413748777)
,p_name=>'Master Records'
,p_template=>wwv_flow_imp.id(16167656412826120468)
,p_display_sequence=>20
,p_region_css_classes=>'search-results'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'t-MediaList--showDesc:t-MediaList--stack'
,p_display_point=>'REGION_POSITION_02'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    "SUBJECT_ID",',
'    NULL                 LINK_CLASS,',
'    APEX_PAGE.GET_URL(',
'        P_ITEMS => ''P8_SUBJECT_ID'',',
'        P_VALUES => "SUBJECT_ID"',
'    )                    LINK,',
'    NULL                 ICON_CLASS,',
'    NULL                 LINK_ATTR,',
'    NULL                 ICON_COLOR_CLASS,',
'    CASE',
'        WHEN COALESCE(:P8_SUBJECT_ID, ''0'') = "SUBJECT_ID"',
'        THEN',
'            ''is-active''',
'        ELSE',
'            '' ''',
'    END                  LIST_CLASS,',
'    ((SUBSTR(Y."SUBJECT_NAME", 1, 50))',
'    ||(',
'        CASE',
'            WHEN LENGTH(Y."SUBJECT_NAME") > 50 THEN',
'                ''...''',
'            ELSE',
'                ''''',
'        END ))           LIST_TEXT,',
'    (SUBSTR(X."SUBJECT_CODE", 1, 50)',
'     ||(',
'        CASE',
'            WHEN LENGTH(X."SUBJECT_CODE") > 50 THEN',
'                ''...''',
'            ELSE',
'                ''''',
'        END ))           LIST_TITLE,',
'    NULL                 LIST_BADGE,',
'    UPPER(X."BRANCH_ID") AS "BRANCH_ID"',
'FROM',
'    "L2_SUBJECTS"      X',
'    LEFT JOIN L2_SUBJECT_DETAILS Y',
'    ON X."SUBJECT_CODE" = Y."SUBJECT_CODE"',
'WHERE',
'    (:P8_SEARCH IS NULL',
'    OR UPPER(X."T_INCHARGE_ID") LIKE ''%''',
'                                     ||UPPER(:P8_SEARCH)',
'                                     ||''%''',
'    OR UPPER(X."BRANCH_ID") LIKE ''%''',
'                                 ||UPPER(:P8_SEARCH)',
'                                 ||''%'' )',
'    AND X."T_INCHARGE_ID" IN (',
'        SELECT',
'            T_ID',
'        FROM',
'            L2_TEACHERS',
'        WHERE',
'            T_EMAIL = LOWER(:APP_USER)',
'    )',
'ORDER BY',
'    X."SUBJECT_CODE";'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P8_SEARCH'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(16167756852386120509)
,p_query_num_rows=>1000
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'<div class="u-tC">No data found.</div>'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3468915569815748780)
,p_query_column_id=>1
,p_column_alias=>'SUBJECT_ID'
,p_column_display_sequence=>1
,p_column_heading=>'SUBJECT_ID'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3468916004532748780)
,p_query_column_id=>2
,p_column_alias=>'LINK_CLASS'
,p_column_display_sequence=>2
,p_column_heading=>'LINK_CLASS'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3468916314109748780)
,p_query_column_id=>3
,p_column_alias=>'LINK'
,p_column_display_sequence=>3
,p_column_heading=>'LINK'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3468916763244748781)
,p_query_column_id=>4
,p_column_alias=>'ICON_CLASS'
,p_column_display_sequence=>4
,p_column_heading=>'ICON_CLASS'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3468917143665748781)
,p_query_column_id=>5
,p_column_alias=>'LINK_ATTR'
,p_column_display_sequence=>5
,p_column_heading=>'LINK_ATTR'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3468917516967748781)
,p_query_column_id=>6
,p_column_alias=>'ICON_COLOR_CLASS'
,p_column_display_sequence=>6
,p_column_heading=>'ICON_COLOR_CLASS'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3468917956776748782)
,p_query_column_id=>7
,p_column_alias=>'LIST_CLASS'
,p_column_display_sequence=>7
,p_column_heading=>'LIST_CLASS'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3468918785702748782)
,p_query_column_id=>8
,p_column_alias=>'LIST_TEXT'
,p_column_display_sequence=>9
,p_column_heading=>'LIST_TEXT'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#LIST_TEXT#<br/>',
'#BRANCH_ID#'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3468918325225748782)
,p_query_column_id=>9
,p_column_alias=>'LIST_TITLE'
,p_column_display_sequence=>8
,p_column_heading=>'LIST_TITLE'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3468919125855748783)
,p_query_column_id=>10
,p_column_alias=>'LIST_BADGE'
,p_column_display_sequence=>10
,p_column_heading=>'LIST_BADGE'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3456133495618124346)
,p_query_column_id=>11
,p_column_alias=>'BRANCH_ID'
,p_column_display_sequence=>20
,p_column_heading=>'Branch Id'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(3468920469438749035)
,p_name=>'L2 Subjects'
,p_template=>wwv_flow_imp.id(16167721656601120494)
,p_display_sequence=>40
,p_region_css_classes=>'js-master-region'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    X."SUBJECT_ID",',
'    UPPER(X."BRANCH_ID") AS "BRANCH",',
'    X."T_INCHARGE_ID" AS "TEACHER ID",',
'    X."TOTAL_CLASS",',
'    y."T_NAME" AS "TEACHER NAME",',
'    y."T_AGE" AS "TEACHER AGE",',
'    y."T_ROLE" AS "TEACHER ROLE",',
'    z."SUBJECT_NAME"',
'FROM',
'    L2_SUBJECTS        X',
'    LEFT JOIN L2_TEACHERS Y',
'    ON X."T_INCHARGE_ID" = Y."T_ID"',
'    LEFT JOIN L2_SUBJECT_DETAILS Z',
'    ON X."SUBJECT_CODE" = Z."SUBJECT_CODE"',
'WHERE',
'    X."SUBJECT_ID" = :P8_SUBJECT_ID'))
,p_display_when_condition=>'P8_SUBJECT_ID'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(16167763074460120512)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No Record Selected'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3468921008463749036)
,p_query_column_id=>1
,p_column_alias=>'SUBJECT_ID'
,p_column_display_sequence=>1
,p_column_heading=>'Subject Id'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from "L2_SUBJECTS"',
'where "SUBJECT_ID" is not null',
'and "SUBJECT_ID" = :P8_SUBJECT_ID'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3456133552064124347)
,p_query_column_id=>2
,p_column_alias=>'BRANCH'
,p_column_display_sequence=>15
,p_column_heading=>'Branch'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3456133615673124348)
,p_query_column_id=>3
,p_column_alias=>'TEACHER ID'
,p_column_display_sequence=>25
,p_column_heading=>'Teacher Id'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3468922636741749036)
,p_query_column_id=>4
,p_column_alias=>'TOTAL_CLASS'
,p_column_display_sequence=>5
,p_column_heading=>'Total Class'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from "L2_SUBJECTS"',
'where "TOTAL_CLASS" is not null',
'and "SUBJECT_ID" = :P8_SUBJECT_ID'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3456133754736124349)
,p_query_column_id=>5
,p_column_alias=>'TEACHER NAME'
,p_column_display_sequence=>35
,p_column_heading=>'Teacher Name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3456133811986124350)
,p_query_column_id=>6
,p_column_alias=>'TEACHER AGE'
,p_column_display_sequence=>45
,p_column_heading=>'Teacher Age'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3456133911027124351)
,p_query_column_id=>7
,p_column_alias=>'TEACHER ROLE'
,p_column_display_sequence=>55
,p_column_heading=>'Teacher Role'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3456134100364124352)
,p_query_column_id=>8
,p_column_alias=>'SUBJECT_NAME'
,p_column_display_sequence=>65
,p_column_heading=>'Subject Name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3468943170895749256)
,p_plug_name=>'No Record Selected'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16167655060117120468)
,p_plug_display_sequence=>70
,p_plug_new_grid_row=>false
,p_location=>null
,p_plug_source=>'No Record Selected'
,p_plug_display_condition_type=>'ITEM_IS_NULL'
,p_plug_display_when_condition=>'P8_SUBJECT_ID'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3472196176323859503)
,p_plug_name=>'View Classes'
,p_title=>'View Classes'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16167721656601120494)
,p_plug_display_sequence=>50
,p_location=>null
,p_plug_source_type=>'NATIVE_HELP_TEXT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3468927197262749040)
,p_plug_name=>'View Classes Table'
,p_title=>'View Classes Table'
,p_parent_plug_id=>wwv_flow_imp.id(3472196176323859503)
,p_region_css_classes=>'js-detail-region'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16167711835329120490)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    X.CLASS_ID,',
'    APEX_PAGE.GET_URL(',
'        P_ITEMS => ''P8_CLASS_ID'',',
'        P_VALUES => X."CLASS_ID"',
'    )            LINK,',
'    X.CLASS_NO,',
'    X.SUBJECT_ID,',
'    X.CLASS_DATE,',
'    Y.SUBJECT_CODE,',
'    Z.SUBJECT_NAME',
'FROM',
'    L2_CLASSES         X',
'    LEFT JOIN L2_SUBJECTS Y',
'    ON X.SUBJECT_ID = Y.SUBJECT_ID',
'    LEFT JOIN L2_SUBJECT_DETAILS Z',
'    ON Y.SUBJECT_CODE = Z.SUBJECT_CODE',
'WHERE',
'    X.SUBJECT_ID = :P8_SUBJECT_ID'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P8_SUBJECT_ID'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'View Classes Table'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(3486523847988097311)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MANOJADKC2004@GMAIL.COM'
,p_internal_uid=>21579484740495082709
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3486523986979097312)
,p_db_column_name=>'CLASS_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Class Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3486524167180097314)
,p_db_column_name=>'CLASS_NO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Class No'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3486524277764097315)
,p_db_column_name=>'SUBJECT_ID'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Subject Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3486524366871097316)
,p_db_column_name=>'CLASS_DATE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Class Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3486524433945097317)
,p_db_column_name=>'SUBJECT_CODE'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Subject Code'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3486524517389097318)
,p_db_column_name=>'SUBJECT_NAME'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Subject Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3486524021014097313)
,p_db_column_name=>'LINK'
,p_display_order=>80
,p_column_identifier=>'B'
,p_column_label=>'Link'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<a href=#LINK#>',
'    <div style="width:full;height:full;color:black;font-weight:bold;">',
'        View Attendance',
'    </div>',
'</a>'))
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(3486638870040116731)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'215795998'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CLASS_ID:CLASS_NO:SUBJECT_ID:CLASS_DATE:SUBJECT_CODE:SUBJECT_NAME:LINK'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3472196684361859508)
,p_plug_name=>'View Attendance'
,p_title=>'View Attendance Of A Class'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16167721656601120494)
,p_plug_display_sequence=>60
,p_location=>null
,p_plug_source_type=>'NATIVE_HELP_TEXT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3472196755893859509)
,p_plug_name=>'View Attendance Table'
,p_parent_plug_id=>wwv_flow_imp.id(3472196684361859508)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16167711835329120490)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT X.CLASS_ID,',
'       X.USN,',
'       Y.STD_NAME,',
'       (CASE WHEN X.ATTENDANCE = ''Y'' THEN ''PRESENT'' ELSE ''ABSENT'' END) AS ATTENDANCE,',
'       (CASE WHEN X.ATTENDANCE = ''Y'' THEN ''color:green;'' ELSE ''color:red;'' END) AS LIST_CLASS,',
'       APEX_ITEM.CHECKBOX2(1, X.STUDENTS_ATTEND_ROW_NO) AS CHECKBOX',
'  FROM L2_STUDENTS_ATTEND X',
'  LEFT JOIN L2_STUDENTS Y ON X.USN = Y.USN',
' WHERE X.CLASS_ID = :P8_CLASS_ID;',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(3472196901584859510)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MANOJADKC2004@GMAIL.COM'
,p_internal_uid=>21565157794091844908
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3472196953298859511)
,p_db_column_name=>'CLASS_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Class Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3472197019822859512)
,p_db_column_name=>'USN'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Usn'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3472197121067859513)
,p_db_column_name=>'STD_NAME'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Std Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3472197255689859514)
,p_db_column_name=>'ATTENDANCE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Attendance'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div style=#LIST_CLASS#>',
'<span style="font-weight:bold;">',
'',
'#ATTENDANCE#',
'</span>',
'',
'</div>'))
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3472197429150859516)
,p_db_column_name=>'CHECKBOX'
,p_display_order=>50
,p_column_identifier=>'F'
,p_column_label=>'Checkbox'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3472197775091859519)
,p_db_column_name=>'LIST_CLASS'
,p_display_order=>60
,p_column_identifier=>'G'
,p_column_label=>'List Class'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(3475698781259943210)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'215686597'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CLASS_ID:USN:STD_NAME:ATTENDANCE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3486524877795097321)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3472196176323859503)
,p_button_name=>'Remove'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--danger:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(16167795321714120528)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Remove Class'
,p_button_position=>'DELETE'
,p_button_redirect_url=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-minus'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3468943651732749256)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(3468920469438749035)
,p_button_name=>'EDIT'
,p_button_static_id=>'edit_master_btn'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(16167795321714120528)
,p_button_image_alt=>'Edit'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:9:&APP_SESSION.::&DEBUG.:RP,9:P9_SUBJECT_ID:&P8_SUBJECT_ID.'
,p_icon_css_classes=>'fa-pencil-square-o'
,p_required_patch=>wwv_flow_imp.id(16167617495353120450)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3468913323821748776)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3468912567247748775)
,p_button_name=>'RESET'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft:t-Button--gapRight'
,p_button_template_id=>wwv_flow_imp.id(16167795321714120528)
,p_button_image_alt=>'Reset'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:8:&APP_SESSION.:RESET:&DEBUG.:RP,8::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3468913804000748776)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3468927197262749040)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(16167795321714120528)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create Class'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:RP,10::'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3472197561194859517)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3472196755893859509)
,p_button_name=>'Invert'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(16167795204145120528)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Present/Absent Invert Button'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3468914510396748777)
,p_name=>'P8_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(3468914078500748777)
,p_prompt=>'Search'
,p_placeholder=>'Search...'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(16167792463926120526)
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large:t-Form-fieldContainer--postTextBlock'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3468926424968749040)
,p_name=>'P8_SUBJECT_ID'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3472196552709859507)
,p_name=>'P8_CLASS_ID'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3468943908193749256)
,p_name=>'Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(3468920469438749035)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3468944601996749257)
,p_event_id=>wwv_flow_imp.id(3468943908193749256)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(3468920469438749035)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3468945077639749257)
,p_event_id=>wwv_flow_imp.id(3468943908193749256)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.message.showPageSuccess(''L2 Subjects row(s) updated.'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3468927243989749040)
,p_name=>'Dialog Closed'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(3468927197262749040)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3468933093235749176)
,p_event_id=>wwv_flow_imp.id(3468927243989749040)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(3468927197262749040)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3468933533144749176)
,p_event_id=>wwv_flow_imp.id(3468927243989749040)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.message.showPageSuccess(''L2 Classes row(s) updated.'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3468944063082749256)
,p_name=>'Perform Search'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P8_SEARCH'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.browserEvent.which === apex.jQuery.ui.keyCode.ENTER'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keypress'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3468945851161749257)
,p_event_id=>wwv_flow_imp.id(3468944063082749256)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(3468914851413748777)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3468946364089749258)
,p_event_id=>wwv_flow_imp.id(3468944063082749256)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CANCEL_EVENT'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3472197676327859518)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Invert Present/Absent'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'BEGIN',
'    FOR I IN 1..APEX_APPLICATION.G_F01.COUNT LOOP',
'        UPDATE L2_STUDENTS_ATTEND X',
'        SET',
'            ATTENDANCE = (',
'                SELECT',
'                    CASE',
'                        WHEN ATTENDANCE = ''N'' THEN',
'                            ''Y''',
'                        ELSE',
'                            ''N''',
'                    END          ATTENDANCE',
'                FROM',
'                    L2_STUDENTS_ATTEND Y',
'                WHERE',
'                    Y.STUDENTS_ATTEND_ROW_NO = TO_NUMBER(APEX_APPLICATION.G_F01(I))',
'            )',
'        WHERE',
'            X.STUDENTS_ATTEND_ROW_NO = TO_NUMBER(APEX_APPLICATION.G_F01(I));',
'    END LOOP;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>21565158568834844916
);
wwv_flow_imp.component_end;
end;
/
