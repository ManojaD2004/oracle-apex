prompt --application/pages/page_00029
begin
--   Manifest
--     PAGE: 00029
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>6454551044931893974
,p_default_application_id=>193996
,p_default_id_offset=>18092960892506985398
,p_default_owner=>'WKSP_INOAUG091DARKMODE'
);
wwv_flow_imp_page.create_page(
 p_id=>29
,p_name=>'OCI Image Feed'
,p_alias=>'OCI-IMAGE-FEED'
,p_step_title=>'OCI Image Feed'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'23'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6286482929136178531)
,p_plug_name=>'OCI Feed Image'
,p_title=>'OCI Feed Image'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16167662142591120470)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select y.USN,',
'       y.STUDENT_NAME,',
'       UPPER(y.BRANCH_ID) BRANCH_ID,',
'       (SELECT x.BRANCH_NAME FROM L2_BRANCH x WHERE x.BRANCH_ID = y.BRANCH_ID) BRANCH_NAME,',
'       IMAGE_DATA,',
'       dbms_lob.getlength(IMAGE_DATA) IMAGE,',
'       FILE_MIMETYPE,',
'       FILE_CHARSET,',
'       FILE_NAME,',
'       AI_OUTPUT,',
'       IMAGE_ID',
'  from L2_IMAGE_TEST_STUDENTS y WHERE y.FILE_CHARSET = :P29_AI_SEARCH;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P29_AI_SEARCH'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(6286483059189178532)
,p_region_id=>wwv_flow_imp.id(6286482929136178531)
,p_layout_type=>'GRID'
,p_grid_column_count=>3
,p_title_adv_formatting=>false
,p_title_column_name=>'USN'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'&STUDENT_NAME.<br/>',
'&IMAGE_ID.'))
,p_body_adv_formatting=>false
,p_body_column_name=>'BRANCH_ID'
,p_second_body_adv_formatting=>false
,p_second_body_column_name=>'BRANCH_NAME'
,p_media_adv_formatting=>false
,p_media_source_type=>'BLOB'
,p_media_blob_column_name=>'IMAGE_DATA'
,p_media_display_position=>'BODY'
,p_media_appearance=>'SQUARE'
,p_media_sizing=>'FIT'
,p_pk1_column_name=>'IMAGE_ID'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6455925862404314855)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16167734083956120499)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(16167618037682120450)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(16167796800214120528)
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30776903894904162786)
,p_name=>'P29_RESPONSE'
,p_item_sequence=>40
,p_prompt=>'Response'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(16167792785719120526)
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(16167617495353120450)
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30819513836164996957)
,p_name=>'P29_AI_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(6286482929136178531)
,p_item_display_point=>'ORDER_BY_ITEM'
,p_item_default=>'FEEDED'
,p_prompt=>'AI Search'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(16167792785719120526)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp.component_end;
end;
/
