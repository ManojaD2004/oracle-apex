prompt --application/pages/page_00017
begin
--   Manifest
--     PAGE: 00017
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>6454551044931893974
,p_default_application_id=>193996
,p_default_id_offset=>18092960892506985398
,p_default_owner=>'WKSP_INOAUG091DARKMODE'
);
wwv_flow_imp_page.create_page(
 p_id=>17
,p_name=>'FORGOT_PASSWORD'
,p_alias=>'FORGOT-PASSWORD'
,p_page_mode=>'MODAL'
,p_step_title=>'FORGOT_PASSWORD'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3489931248795263905)
,p_plug_name=>'RESET PASSWORD'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(16167721656601120494)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3489931572891263908)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(3489931248795263905)
,p_button_name=>'CLOSE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(16167795204145120528)
,p_button_image_alt=>'Close'
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:9999:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3489931707506263910)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(3489931248795263905)
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(16167795204145120528)
,p_button_image_alt=>'Submit'
,p_button_position=>'CREATE'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(3489932183634263914)
,p_branch_name=>'LOGIN'
,p_branch_action=>'f?p=&APP_ID.:9999:&SESSION.::&DEBUG.:9999::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3489931307531263906)
,p_name=>'P17_T_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(3489931248795263905)
,p_use_cache_before_default=>'NO'
,p_source=>'T_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3489931444550263907)
,p_name=>'P17_T_EMAIL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(3489931248795263905)
,p_use_cache_before_default=>'NO'
,p_prompt=>'T Email'
,p_source=>'T_EMAIL'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(16167792785719120526)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(3489931862494263911)
,p_validation_name=>'MAIL'
,p_validation_sequence=>10
,p_validation=>'P17_T_EMAIL'
,p_validation2=>'^[a-zA-Z0-9_!#$%&''*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$'
,p_validation_type=>'REGULAR_EXPRESSION'
,p_error_message=>'ENTER A VALID MAIL!'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(3489932289183263915)
,p_validation_name=>'GET_MAIL'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'            DECLARE',
'                v_email   NVARCHAR2 (50);',
'                BEGIN',
'                SELECT T_EMAIL',
'                  INTO v_email',
'                  FROM L2_TEACHERS',
'                 WHERE T_EMAIL = :P17_T_EMAIL;',
'                RETURN TRUE;',
'            EXCEPTION',
'                WHEN OTHERS',
'                THEN',
'                    RETURN FALSE;',
'            END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'THE PROVIDED MAIL IS NOT REGISTERED WITH US.'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3489932011514263913)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin ',
'teacher_login.request_reset_password(:P3_EMAIL);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>21582892904021249311
);
wwv_flow_imp.component_end;
end;
/
