prompt --application/pages/page_00026
begin
--   Manifest
--     PAGE: 00026
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>6454551044931893974
,p_default_application_id=>193996
,p_default_id_offset=>18092960892506985398
,p_default_owner=>'WKSP_INOAUG091DARKMODE'
);
wwv_flow_imp_page.create_page(
 p_id=>26
,p_name=>'Camera'
,p_alias=>'CAMERA'
,p_step_title=>'Camera'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3454634419739268438)
,p_plug_name=>'Detect Face'
,p_title=>'Detect Face'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(16167721656601120494)
,p_plug_display_sequence=>100
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div>',
'    <h1>Camera Access</h1>',
'',
'    <div style="display: flex; justify-content: center; align-items: center; ">',
'    <video id="video" style="width: 45%; height: 45%;" autoplay></video>',
'   ',
'   ',
'   </div>',
'     <br></br>',
'',
'    <div style="display: flex; justify-content: center; align-items: center;">',
'     <button id="capture" style="  background-color: #1e293b; color: #fff; border: 1px solid #000;margin: 5px 5px;border-radius: 5px;padding: 10px 15px;cursor: pointer;transition: all 0.2s ease-in-out;font-weight: bold;">Capture Photo</button>',
'    </div>',
'       <div style="display: flex; justify-content: center; align-items: center; height: full;">  ',
'   <canvas id="canvas"  style="width: 45%; height: 200px;"></canvas> ',
'         </div> ',
'    <script>',
'        const video = document.getElementById(''video'');',
'        const canvas = document.getElementById(''canvas'');',
'        const context = canvas.getContext(''2d'');',
'        const captureButton = document.getElementById(''capture'');',
'        const aFileInput = document.getElementById(''P26_IMAGE_DATA'');',
'        const textInput = document.getElementById(''P26_FILE_CHARSET'');',
'        const textInput1 = document.getElementById(''P26_FILE_MIMETYPE'');',
'        const textInput2 = document.getElementById(''P26_FILE_NAME'');',
'',
'        navigator.mediaDevices.getUserMedia({ video: true })',
'            .then(function(stream) {',
'                video.srcObject = stream; ',
'                video.play();',
'            })',
'            .catch(function(err) {',
'                console.error("Error accessing the camera: " + err);',
'            });',
'',
'        captureButton.addEventListener(''click'', function(e) {',
'            e.preventDefault();',
'            context.drawImage(video, 0, 0, canvas.width, canvas.height);',
'            canvas.toBlob(function(blob) {',
'                const file = new File([blob], ''manojad.jpeg'', { type: ''image/jpeg'' });',
'                const dataTransfer = new DataTransfer();',
'                dataTransfer.items.add(file);',
'                aFileInput.files = dataTransfer.files;',
'                textInput.value = ''DETECT'';',
'                textInput1.value = ''image/jpeg'';',
'                textInput2.value = ''image.jpeg'';',
'                console.log(aFileInput);',
'                console.log(aFileInput.files);',
'                const event = new Event(''change'', { bubbles: true });',
'                aFileInput.dispatchEvent(event);',
'                console.log(dataTransfer.files);',
'            }, ''image/png'');',
'        });',
'    </script>',
'</div>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6286483138243178533)
,p_plug_name=>'Detect Upload Image'
,p_title=>'Detect Upload Image'
,p_region_name=>'detect-image-upload'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(16167721656601120494)
,p_plug_display_sequence=>90
,p_query_type=>'TABLE'
,p_query_table=>'L2_IMAGE_TEST_STUDENTS'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6311746734139221558)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16167734083956120499)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(16167618037682120450)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(16167796800214120528)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6468439306151550525)
,p_plug_name=>'List Subject'
,p_title=>'List Subject'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16167721656601120494)
,p_plug_display_sequence=>140
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_location=>null
,p_plug_source_type=>'NATIVE_HELP_TEXT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6468437156818550504)
,p_plug_name=>'List Subject'
,p_title=>'List Subject'
,p_parent_plug_id=>wwv_flow_imp.id(6468439306151550525)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16167711835329120490)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select X.SUBJECT_ID,',
'       X.BRANCH_ID,',
'       X.SUBJECT_CODE,',
'       X.T_INCHARGE_ID,',
'       X.TOTAL_CLASS,',
'       Y.SUBJECT_NAME,',
'       Z.CLASS_ID',
'  FROM L2_SUBJECTS X, L2_SUBJECT_DETAILS Y, L2_CLASSES Z',
'  WHERE X.T_INCHARGE_ID IN (SELECT T_ID FROM L2_TEACHERS WHERE T_EMAIL = LOWER(:APP_USER)) AND',
'  X.SUBJECT_CODE = Y.SUBJECT_CODE AND X.SUBJECT_ID = Z.SUBJECT_ID;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'List Subject'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(6468437264247550505)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MANOJADKC2004@GMAIL.COM'
,p_internal_uid=>24561398156754535903
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6468437517369550508)
,p_db_column_name=>'BRANCH_ID'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Branch Id'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6517818532753385813)
,p_db_column_name=>'SUBJECT_ID'
,p_display_order=>40
,p_is_primary_key=>'Y'
,p_column_identifier=>'S'
,p_column_label=>'Subject Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6517818699154385814)
,p_db_column_name=>'SUBJECT_CODE'
,p_display_order=>50
,p_column_identifier=>'T'
,p_column_label=>'Subject Code'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6517818799429385815)
,p_db_column_name=>'T_INCHARGE_ID'
,p_display_order=>60
,p_column_identifier=>'U'
,p_column_label=>'T Incharge Id'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6517818809497385816)
,p_db_column_name=>'TOTAL_CLASS'
,p_display_order=>70
,p_column_identifier=>'V'
,p_column_label=>'Total Class'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6517818984305385817)
,p_db_column_name=>'SUBJECT_NAME'
,p_display_order=>80
,p_column_identifier=>'W'
,p_column_label=>'Subject Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6517819039061385818)
,p_db_column_name=>'CLASS_ID'
,p_display_order=>90
,p_column_identifier=>'X'
,p_column_label=>'Class Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(6486628505321098920)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'245795894'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BRANCH_ID'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6517819340256385821)
,p_plug_name=>'List Students By Image'
,p_title=>'List Students By Image'
,p_parent_plug_id=>wwv_flow_imp.id(6468439306151550525)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16167711835329120490)
,p_plug_display_sequence=>70
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select USN, STUDENT_NAME,',
'       (SQRT( POWER(X0 - :P26_X0, 2) + POWER(Y0 - :P26_Y0, 2) ) + SQRT( POWER(X1 - :P26_X1, 2) + POWER(Y1 - :P26_Y1, 2) )',
'       + SQRT(POWER(X2 - :P26_X2, 2) + POWER(Y2 - :P26_Y2, 2) ) + SQRT( POWER(X3 - :P26_X3, 2) + POWER(Y3 - :P26_Y3, 2) ) )',
'       / 4 AS DISTANCE',
'  from L2_IMAGE_TEST_STUDENTS',
'  WHERE FILE_CHARSET = ''FEEDED'' ',
'  ORDER BY DISTANCE',
'  FETCH FIRST 10 ROWS ONLY;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'List Students By Image'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(6517819443320385822)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MANOJADKC2004@GMAIL.COM'
,p_internal_uid=>24610780335827371220
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6517819552181385823)
,p_db_column_name=>'USN'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Usn'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6517819703905385824)
,p_db_column_name=>'STUDENT_NAME'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Student Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6517819788601385825)
,p_db_column_name=>'DISTANCE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Distance'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(7354307957844515310)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'254472689'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'USN:STUDENT_NAME:DISTANCE'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6517818054900385808)
,p_plug_name=>'List Class'
,p_title=>'List Class'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16167721656601120494)
,p_plug_display_sequence=>120
,p_location=>null
,p_plug_source_type=>'NATIVE_HELP_TEXT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6286485014515178552)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(6286483138243178533)
,p_button_name=>'Create'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(16167795204145120528)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'CREATE'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6468439362932550526)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(6517818054900385808)
,p_button_name=>'Process'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(16167795204145120528)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Process Detect'
,p_button_position=>'NEXT'
,p_button_condition=>'P26_IMAGE_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6517819138580385819)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(6517818054900385808)
,p_button_name=>'Present'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(16167795204145120528)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'P / A Invert '
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6286483406809178535)
,p_name=>'P26_USN'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(6286483138243178533)
,p_item_source_plug_id=>wwv_flow_imp.id(6286483138243178533)
,p_item_default=>'1MP22CS031'
,p_prompt=>'Usn'
,p_source=>'USN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>100
,p_field_template=>wwv_flow_imp.id(16167792785719120526)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_required_patch=>wwv_flow_imp.id(16167617495353120450)
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6286483503852178536)
,p_name=>'P26_STUDENT_NAME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(6286483138243178533)
,p_item_source_plug_id=>wwv_flow_imp.id(6286483138243178533)
,p_item_default=>'Manoja D'
,p_prompt=>'Student Name'
,p_source=>'STUDENT_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>100
,p_field_template=>wwv_flow_imp.id(16167792785719120526)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_required_patch=>wwv_flow_imp.id(16167617495353120450)
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6286483577481178537)
,p_name=>'P26_BRANCH_ID'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(6286483138243178533)
,p_item_source_plug_id=>wwv_flow_imp.id(6286483138243178533)
,p_item_default=>'cse'
,p_prompt=>'Branch Id'
,p_source=>'BRANCH_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_field_template=>wwv_flow_imp.id(16167792785719120526)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_required_patch=>wwv_flow_imp.id(16167617495353120450)
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6286483638335178538)
,p_name=>'P26_IMAGE_DATA'
,p_source_data_type=>'BLOB'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(6286483138243178533)
,p_item_source_plug_id=>wwv_flow_imp.id(6286483138243178533)
,p_prompt=>'Image Data'
,p_source=>'IMAGE_DATA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_IMAGE_UPLOAD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(16167792785719120526)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'DB_COLUMN'
,p_attribute_06=>'Y'
,p_attribute_12=>'DROPZONE_ICON'
,p_attribute_18=>'N'
,p_attribute_23=>'AUTO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6286483782306178539)
,p_name=>'P26_FILE_MIMETYPE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(6286483138243178533)
,p_item_source_plug_id=>wwv_flow_imp.id(6286483138243178533)
,p_prompt=>'File Mimetype'
,p_source=>'FILE_MIMETYPE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(16167792785719120526)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6286483821034178540)
,p_name=>'P26_FILE_CHARSET'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(6286483138243178533)
,p_item_source_plug_id=>wwv_flow_imp.id(6286483138243178533)
,p_prompt=>'File Charset'
,p_source=>'FILE_CHARSET'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(16167792785719120526)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6286483995591178541)
,p_name=>'P26_FILE_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(6286483138243178533)
,p_item_source_plug_id=>wwv_flow_imp.id(6286483138243178533)
,p_prompt=>'File Name'
,p_source=>'FILE_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(16167792785719120526)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6286484017381178542)
,p_name=>'P26_AI_OUTPUT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(6286483138243178533)
,p_item_source_plug_id=>wwv_flow_imp.id(6286483138243178533)
,p_prompt=>'Ai Output'
,p_source=>'AI_OUTPUT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>2000
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(16167792785719120526)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_required_patch=>wwv_flow_imp.id(16167617495353120450)
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6286484136232178543)
,p_name=>'P26_X1'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6286484297862178544)
,p_name=>'P26_Y1'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6286484317149178545)
,p_name=>'P26_X2'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6286484494976178546)
,p_name=>'P26_Y2'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6286484606726178547)
,p_name=>'P26_X3'
,p_item_sequence=>70
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6286484690266178548)
,p_name=>'P26_Y3'
,p_item_sequence=>80
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6286484773463178549)
,p_name=>'P26_X0'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6286484831308178550)
,p_name=>'P26_Y0'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6286484940642178551)
,p_name=>'P26_IMAGE_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(6286483138243178533)
,p_item_source_plug_id=>wwv_flow_imp.id(6286483138243178533)
,p_prompt=>'IMAGE_ID'
,p_source=>'IMAGE_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(16167792785719120526)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6468440087198550533)
,p_name=>'P26_RESPONSE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(6468439306151550525)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6517818233318385810)
,p_name=>'P26_SUBJECT_ID'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(6517818054900385808)
,p_prompt=>'Subject Id'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT SUBJECT_ID FROM L2_SUBJECTS WHERE T_INCHARGE_ID IN (SELECT T_ID FROM L2_TEACHERS',
'WHERE T_EMAIL =  LOWER(:APP_USER));'))
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(16167792785719120526)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_required_patch=>wwv_flow_imp.id(16167617495353120450)
,p_attribute_01=>'CONTAINS_IGNORE'
,p_attribute_04=>'Y'
,p_attribute_05=>'7'
,p_attribute_09=>'1'
,p_attribute_10=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6517818308684385811)
,p_name=>'P26_CLASS_ID'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(6517818054900385808)
,p_prompt=>'Class Id'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'       Z.CLASS_ID',
'  FROM L2_SUBJECTS X, L2_SUBJECT_DETAILS Y, L2_CLASSES Z',
'  WHERE X.T_INCHARGE_ID IN (SELECT T_ID FROM L2_TEACHERS WHERE T_EMAIL = LOWER(:APP_USER)) AND',
'  X.SUBJECT_CODE = Y.SUBJECT_CODE AND X.SUBJECT_ID = Z.SUBJECT_ID;'))
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(16167792785719120526)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'CONTAINS_IGNORE'
,p_attribute_04=>'Y'
,p_attribute_05=>'7'
,p_attribute_09=>'1'
,p_attribute_10=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6517818493070385812)
,p_name=>'P26_USN_RES'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(6517818054900385808)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT USN',
'FROM L2_IMAGE_TEST_STUDENTS',
'WHERE FILE_CHARSET = ''FEEDED''',
'ORDER BY (',
'    SQRT(POWER(X0 - :P26_X0, 2) + POWER(Y0 - :P26_Y0, 2)) +',
'    SQRT(POWER(X1 - :P26_X1, 2) + POWER(Y1 - :P26_Y1, 2)) +',
'    SQRT(POWER(X2 - :P26_X2, 2) + POWER(Y2 - :P26_Y2, 2)) +',
'    SQRT(POWER(X3 - :P26_X3, 2) + POWER(Y3 - :P26_Y3, 2))',
')',
'FETCH FIRST 1 ROW ONLY;'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Usn Res'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(16167792785719120526)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6517819892843385826)
,p_name=>'P26_LIST_DETECT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(6468439306151550525)
,p_item_default=>'List Subjects'
,p_prompt=>'List Subjects'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(16167792785719120526)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6517819940556385827)
,p_name=>'P26_LIST_DETECT_IMAGES'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(6468439306151550525)
,p_item_default=>'List Detect'
,p_prompt=>'List Detect'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(16167792785719120526)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(6468437037762550503)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(6286483138243178533)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Insert Image'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(6286485014515178552)
,p_process_success_message=>'Inserted!'
,p_internal_uid=>24561397930269535901
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(6468439467109550527)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Process AI'
,p_attribute_01=>'N'
,p_process_error_message=>'AI Process Error!'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(6468439362932550526)
,p_process_success_message=>'AI Process Done!'
,p_internal_uid=>24561400359616535925
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(6517819275717385820)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Present/Absent Invert '
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
' UPDATE L2_STUDENTS_ATTEND X',
'        SET',
'            ATTENDANCE = (',
'                SELECT',
'                    CASE',
'                        WHEN ATTENDANCE = ''N'' THEN',
'                            ''Y''',
'                        ELSE',
'                            ''N''',
'                    END          ATTENDANCE',
'                FROM',
'                    L2_STUDENTS_ATTEND Y',
'                WHERE',
'                   Y.USN = :P26_USN_RES AND Y.CLASS_ID = :P26_CLASS_ID',
'            )',
'        WHERE',
'            X.USN = :P26_USN_RES AND X.CLASS_ID = :P26_CLASS_ID;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(6517819138580385819)
,p_internal_uid=>24610780168224371218
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(6286483278505178534)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(6286483138243178533)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Camera'
,p_internal_uid=>24379444171012163932
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(6468439550695550528)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(6468439467109550527)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Call Rest API'
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(6214240942352707410)
,p_web_src_operation_id=>wwv_flow_imp.id(6214241596625707411)
,p_attribute_01=>'WEB_SOURCE'
,p_internal_uid=>24561400443202535926
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(6468439647554550529)
,p_page_id=>26
,p_web_src_param_id=>wwv_flow_imp.id(6263986402503302296)
,p_page_process_id=>wwv_flow_imp.id(6468439550695550528)
,p_value_type=>'STATIC'
,p_value=>'ocid1.compartment.oc1..aaaaaaaa6zowrkkrrnnf5wqzwipmry7dflx2dltxstgbow3ydgzm74xic4fa'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(6468439733963550530)
,p_page_id=>26
,p_web_src_param_id=>wwv_flow_imp.id(6263987364151302297)
,p_page_process_id=>wwv_flow_imp.id(6468439550695550528)
,p_value_type=>'STATIC'
,p_value=>'FACE_DETECTION'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(6468439809492550531)
,p_page_id=>26
,p_web_src_param_id=>wwv_flow_imp.id(6263986810541302297)
,p_page_process_id=>wwv_flow_imp.id(6468439550695550528)
,p_value_type=>'SQL_QUERY'
,p_value=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    REPLACE(REPLACE(APEX_WEB_SERVICE.BLOB2CLOBBASE64(IMAGE_DATA),',
'                    CHR(10),',
'                    ''''),',
'            CHR(13),',
'            '''') AS FILE_DATA',
'FROM',
'    L2_IMAGE_TEST_STUDENTS',
'WHERE IMAGE_ID = :P26_IMAGE_ID;'))
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(6468439927623550532)
,p_page_id=>26
,p_web_src_param_id=>wwv_flow_imp.id(6264953667292310276)
,p_page_process_id=>wwv_flow_imp.id(6468439550695550528)
,p_value_type=>'ITEM'
,p_value=>'P26_RESPONSE'
,p_ignore_output=>false
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(6468440201723550534)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(6468439467109550527)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Parse Output'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    VX0          NUMBER;',
'    VY0          NUMBER;',
'    VX1          NUMBER;',
'    VY1          NUMBER;',
'    VX2          NUMBER;',
'    VY2          NUMBER;',
'    VX3          NUMBER;',
'    VY3          NUMBER;',
'    RES_USN VARCHAR2(1000);',
'BEGIN',
'    BEGIN',
'        DBMS_OUTPUT.PUT_LINE(''0'');',
'        SELECT',
'            X,',
'            Y INTO VX0,',
'            VY0',
'        FROM',
'            JSON_TABLE(:P26_RESPONSE,',
'            ''$.detectedFaces[0].boundingPolygon.normalizedVertices[0]'' COLUMNS ( X NUMBER PATH ''$.x'',',
'            Y NUMBER PATH ''$.y'' ) );',
'        APEX_UTIL.SET_SESSION_STATE(''P26_X0'', VX0);',
'        APEX_UTIL.SET_SESSION_STATE(''P26_Y0'', VY0);',
'    EXCEPTION',
'        WHEN OTHERS THEN',
'            DBMS_OUTPUT.PUT_LINE(''Error processing vertex 0: ''',
'                                 || SQLERRM);',
'    END;',
'    BEGIN',
'        DBMS_OUTPUT.PUT_LINE(''1'');',
'        SELECT',
'            X,',
'            Y INTO VX1,',
'            VY1',
'        FROM',
'            JSON_TABLE(:P26_RESPONSE,',
'            ''$.detectedFaces[0].boundingPolygon.normalizedVertices[1]'' COLUMNS ( X NUMBER PATH ''$.x'',',
'            Y NUMBER PATH ''$.y'' ) );',
'        APEX_UTIL.SET_SESSION_STATE(''P26_X1'', VX1);',
'        APEX_UTIL.SET_SESSION_STATE(''P26_Y1'', VY1);',
'    EXCEPTION',
'        WHEN OTHERS THEN',
'            DBMS_OUTPUT.PUT_LINE(''Error processing vertex 1: ''',
'                                 || SQLERRM);',
'    END;',
'    BEGIN',
'        DBMS_OUTPUT.PUT_LINE(''2'');',
'        SELECT',
'            X,',
'            Y INTO VX2,',
'            VY2',
'        FROM',
'            JSON_TABLE(:P26_RESPONSE,',
'            ''$.detectedFaces[0].boundingPolygon.normalizedVertices[2]'' COLUMNS ( X NUMBER PATH ''$.x'',',
'            Y NUMBER PATH ''$.y'' ) );',
'        APEX_UTIL.SET_SESSION_STATE(''P26_X2'', VX2);',
'        APEX_UTIL.SET_SESSION_STATE(''P26_Y2'', VY2);',
'    EXCEPTION',
'        WHEN OTHERS THEN',
'            DBMS_OUTPUT.PUT_LINE(''Error processing vertex 2: ''',
'                                 || SQLERRM);',
'    END;',
'    BEGIN',
'        DBMS_OUTPUT.PUT_LINE(''3'');',
'        SELECT',
'            X,',
'            Y INTO VX3,',
'            VY3',
'        FROM',
'            JSON_TABLE(:P26_RESPONSE,',
'            ''$.detectedFaces[0].boundingPolygon.normalizedVertices[3]'' COLUMNS ( X NUMBER PATH ''$.x'',',
'            Y NUMBER PATH ''$.y'' ) );',
'        APEX_UTIL.SET_SESSION_STATE(''P26_X3'', VX3);',
'        APEX_UTIL.SET_SESSION_STATE(''P26_Y3'', VY3);',
'    EXCEPTION',
'        WHEN OTHERS THEN',
'            DBMS_OUTPUT.PUT_LINE(''Error processing vertex 3: ''',
'                                 || SQLERRM);',
'    END;',
'    SELECT USN INTO RES_USN',
'FROM L2_IMAGE_TEST_STUDENTS',
'WHERE FILE_CHARSET = ''FEEDED''',
'ORDER BY (',
'    SQRT(POWER(X0 - VX0, 2) + POWER(Y0 - VY0, 2)) +',
'    SQRT(POWER(X1 - VX1, 2) + POWER(Y1 - VY1, 2)) +',
'    SQRT(POWER(X2 - VX2, 2) + POWER(Y2 - VY2, 2)) +',
'    SQRT(POWER(X3 - VX3, 2) + POWER(Y3 - VY3, 2))',
')',
'FETCH FIRST 1 ROW ONLY;',
'   APEX_UTIL.SET_SESSION_STATE(''P26_USN_RES'', RES_USN);',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>24561401094230535932
);
wwv_flow_imp.component_end;
end;
/
