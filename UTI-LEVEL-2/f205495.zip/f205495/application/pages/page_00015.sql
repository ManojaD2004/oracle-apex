prompt --application/pages/page_00015
begin
--   Manifest
--     PAGE: 00015
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>6454551044931893974
,p_default_application_id=>193996
,p_default_id_offset=>18092960892506985398
,p_default_owner=>'WKSP_INOAUG091DARKMODE'
);
wwv_flow_imp_page.create_page(
 p_id=>15
,p_name=>'OCI Image'
,p_alias=>'OCI-IMAGE'
,p_step_title=>'OCI Image'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'23'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30614682246337890456)
,p_plug_name=>'OCI Image'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleA'
,p_plug_template=>wwv_flow_imp.id(16167662142591120470)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "IMAGE_ID",',
'       "USN",',
'       ( select l1."EMAIL_ID" from "L2_STUDENTS" l1 where l1."USN" = m."USN") "USN_L$1",',
'       "STUDENT_NAME",',
'       "BRANCH_ID",',
'       ( select l2."BRANCH_NAME" from "L2_BRANCH" l2 where l2."BRANCH_ID" = m."BRANCH_ID") "BRANCH_ID_L$2",',
'       "IMAGE_DATA",',
'       dbms_lob.getlength(IMAGE_DATA) IMAGE,',
'       "FILE_MIMETYPE",',
'       "FILE_CHARSET",',
'       "FILE_NAME"',
'from "L2_IMAGE_STUDENTS" m',
'WHERE LOWER(AI_OUTPUT) LIKE ''%'' || LOWER(:P15_AI_SEARCH) || ''%'';'))
,p_query_order_by_type=>'ITEM'
,p_query_order_by=>'{ "itemName": "P15_ORDER_BY", "orderBys": [{"key":"USN_L$1","expr":"\"USN_L$1\" asc"},{"key":"STUDENT_NAME","expr":"\"STUDENT_NAME\" asc"}]}'
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P15_AI_SEARCH'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(6263382979588540656)
,p_region_id=>wwv_flow_imp.id(30614682246337890456)
,p_layout_type=>'GRID'
,p_grid_column_count=>3
,p_title_adv_formatting=>false
,p_title_column_name=>'USN_L$1'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>'<h1>&STUDENT_NAME.<h1>'
,p_body_adv_formatting=>true
,p_body_html_expr=>'<h5>&BRANCH_ID_L$2.<h5>'
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_media_source_type=>'BLOB'
,p_media_blob_column_name=>'IMAGE_DATA'
,p_media_display_position=>'BODY'
,p_media_appearance=>'SQUARE'
,p_media_sizing=>'COVER'
,p_pk1_column_name=>'USN'
,p_mime_type_column_name=>'FILE_MIMETYPE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6228016493324862533)
,p_name=>'P15_RESPONSE'
,p_item_sequence=>40
,p_prompt=>'Response'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(16167792785719120526)
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(16167617495353120450)
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6270626434585696704)
,p_name=>'P15_AI_SEARCH'
,p_item_sequence=>20
,p_prompt=>'AI Search'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(16167792785719120526)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30614685691090890466)
,p_name=>'P15_ORDER_BY'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(30614682246337890456)
,p_item_display_point=>'ORDER_BY_ITEM'
,p_item_default=>'USN_L$1'
,p_prompt=>'Order By'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Usn L$1;USN_L$1,Student Name;STUDENT_NAME'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(16167792785719120526)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp.component_end;
end;
/
