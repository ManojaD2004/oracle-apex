prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>6454551044931893974
,p_default_application_id=>193996
,p_default_id_offset=>18092960892506985398
,p_default_owner=>'WKSP_INOAUG091DARKMODE'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'Assign Teacher To Subject'
,p_alias=>'ASSIGN-TEACHER-TO-SUBJECT'
,p_step_title=>'Assign Teacher To Subject'
,p_allow_duplicate_submissions=>'N'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Scroll Results Only in Side Column */',
'.t-Body-side {',
'    display: flex;',
'    flex-direction: column;',
'    overflow: hidden;',
'}',
'.search-results {',
'    flex: 1;',
'    overflow: auto;',
'}',
'/* Format Search Region */',
'.search-region {',
'    border-bottom: 1px solid rgba(0,0,0,.1);',
'    flex-shrink: 0;',
'}'))
,p_step_template=>wwv_flow_imp.id(16167622059619120453)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3440868167099839738)
,p_plug_name=>'Already Assigned Students'
,p_title=>'Already Assigned Students'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16167721656601120494)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_location=>null
,p_plug_source_type=>'NATIVE_HELP_TEXT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3440867488320839731)
,p_plug_name=>'Already Assigned Students Table'
,p_title=>'Already Assigned Students Table'
,p_parent_plug_id=>wwv_flow_imp.id(3440868167099839738)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16167711835329120490)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    Y."EMAIL_ID",',
'    UPPER(Y."BRANCH_ID") AS "BRANCH_ID",',
'    Y."USN",',
'    Y."STD_NAME",',
'    APEX_ITEM.CHECKBOX2(1, Y."STD_ROW_NO") AS "CHECKBOX",',
'    X."SUBJECT_ID"',
'FROM',
'    L2_STUDENTS_SUBJECTS X',
'    LEFT JOIN L2_STUDENTS Y',
'    ON X."USN" = Y."USN"',
'    LEFT JOIN L2_SUBJECTS Z ON',
'    Z."SUBJECT_ID" = X."SUBJECT_ID"',
'WHERE',
'    X."SUBJECT_ID" = :P4_SUBJECT_ID AND Z.TOTAL_CLASS = 0',
'ORDER BY',
'    Y."USN";'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Already Assigned Students Table'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(3440867535528839732)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MANOJADKC2004@GMAIL.COM'
,p_internal_uid=>21533828428035825130
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3440867657598839733)
,p_db_column_name=>'EMAIL_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Email Id'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3440867742988839734)
,p_db_column_name=>'BRANCH_ID'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Branch Id'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3440867872239839735)
,p_db_column_name=>'USN'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Usn'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3440867940397839736)
,p_db_column_name=>'STD_NAME'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Std Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3440868280013839739)
,p_db_column_name=>'CHECKBOX'
,p_display_order=>50
,p_column_identifier=>'F'
,p_column_label=>'Checkbox'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3456133377592124345)
,p_db_column_name=>'SUBJECT_ID'
,p_display_order=>60
,p_column_identifier=>'G'
,p_column_label=>'Subject Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(3452982184820232536)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'215459432'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'EMAIL_ID:BRANCH_ID:USN:STD_NAME'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3440868568913839742)
,p_plug_name=>'Assign Students To Subject'
,p_title=>'Assign Students To Subject'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16167721656601120494)
,p_plug_display_sequence=>60
,p_location=>null
,p_plug_source_type=>'NATIVE_HELP_TEXT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3448450442596123772)
,p_plug_name=>'Assign Students To Subject Table'
,p_title=>'Assign Students To Subject Table'
,p_parent_plug_id=>wwv_flow_imp.id(3440868568913839742)
,p_region_css_classes=>'js-detail-region'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16167711835329120490)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    APEX_ITEM.CHECKBOX2(1, Y."STD_ROW_NO", ''CHECKED'') AS "CHECKBOX",',
'    Y."EMAIL_ID",',
'    UPPER(X."BRANCH_ID")                              AS "BRANCH_ID",',
'    Y."USN",',
'    Y."STD_NAME",',
'    X."SUBJECT_ID"',
'FROM',
'    L2_SUBJECTS          X',
'    LEFT JOIN L2_STUDENTS Y',
'    ON X."BRANCH_ID" = Y."BRANCH_ID"',
'WHERE',
'    X.TOTAL_CLASS = 0',
'    AND X."SUBJECT_ID" = :P4_SUBJECT_ID',
'    AND Y."USN" NOT IN (',
'        SELECT',
'            Z."USN"',
'        FROM',
'            L2_STUDENTS_SUBJECTS Z',
'        WHERE',
'            Z."SUBJECT_ID" = :P4_SUBJECT_ID',
'    )',
'ORDER BY',
'    Y."USN"'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P4_SUBJECT_ID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Assign Students To Subject Table'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(3440869021389839747)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MANOJADKC2004@GMAIL.COM'
,p_internal_uid=>21533829913896825145
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3440869247355839749)
,p_db_column_name=>'EMAIL_ID'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Email Id'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3440869369907839750)
,p_db_column_name=>'BRANCH_ID'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Branch Id'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3440869445833839751)
,p_db_column_name=>'USN'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Usn'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3440869528631839752)
,p_db_column_name=>'STD_NAME'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Std Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3456132654493124338)
,p_db_column_name=>'CHECKBOX'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Checkbox'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3456133295871124344)
,p_db_column_name=>'SUBJECT_ID'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Subject Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(3455584243640090342)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'215485452'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'EMAIL_ID:BRANCH_ID:USN:STD_NAME'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3448434840858123515)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16167734083956120499)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(16167618037682120450)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(16167796800214120528)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3448436405671123519)
,p_plug_name=>'Search'
,p_region_css_classes=>'search-region padding-md'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(16167655060117120468)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(3448437179697123520)
,p_name=>'Master Records'
,p_template=>wwv_flow_imp.id(16167656412826120468)
,p_display_sequence=>20
,p_region_css_classes=>'search-results'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'t-MediaList--showDesc:t-MediaList--stack'
,p_display_point=>'REGION_POSITION_02'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    x."SUBJECT_ID",',
'    NULL         LINK_CLASS,',
'    APEX_PAGE.GET_URL(',
'        P_ITEMS => ''P4_SUBJECT_ID'',',
'        P_VALUES => x."SUBJECT_ID"',
'    )            LINK,',
'    NULL         ICON_CLASS,',
'    NULL         LINK_ATTR,',
'    NULL         ICON_COLOR_CLASS,',
'    CASE',
'        WHEN COALESCE(:P4_SUBJECT_ID, ''0'') = "SUBJECT_ID"',
'        THEN',
'            ''is-active''',
'        ELSE',
'            '' ''',
'    END          LIST_CLASS,',
'    (UPPER(SUBSTR(x."BRANCH_ID", 1, 50))',
'     ||(',
'        CASE',
'            WHEN LENGTH(x."BRANCH_ID") > 50 THEN',
'                ''...''',
'            ELSE',
'                ''''',
'        END ))   LIST_TEXT,',
'    (SUBSTR(x."SUBJECT_CODE", 1, 50)',
'     ||(',
'        CASE',
'            WHEN LENGTH(x."SUBJECT_CODE") > 50 THEN',
'                ''...''',
'            ELSE',
'                ''''',
'        END ))   LIST_TITLE,',
'    NULL         LIST_BADGE,',
'    y."SUBJECT_NAME"',
'FROM',
'    "L2_SUBJECTS" x',
'LEFT JOIN L2_SUBJECT_DETAILS y ON x."SUBJECT_CODE" = y."SUBJECT_CODE"',
'WHERE',
'    (:P4_SEARCH IS NULL',
'    OR UPPER(x."BRANCH_ID") LIKE ''%''',
'                                 ||UPPER(:P4_SEARCH)',
'                                 ||''%''',
'    OR UPPER(x."SUBJECT_CODE") LIKE ''%''',
'                                    ||UPPER(:P4_SEARCH)',
'                                    ||''%'' )',
'    AND (x."BRANCH_ID" IN (',
'        SELECT',
'            BRANCH_ID',
'        FROM',
'            L2_TEACHERS',
'        WHERE',
'            T_EMAIL = LOWER(:APP_USER) AND T_ROLE = ''Professor & Head'' OR T_ROLE = ''Principal''',
'    ))',
'ORDER BY',
'    x."SUBJECT_CODE"'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P4_SEARCH'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(16167756852386120509)
,p_query_num_rows=>1000
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'<div class="u-tC">No data found.</div>'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3448437817643123522)
,p_query_column_id=>1
,p_column_alias=>'SUBJECT_ID'
,p_column_display_sequence=>1
,p_column_heading=>'SUBJECT_ID'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3448438295478123523)
,p_query_column_id=>2
,p_column_alias=>'LINK_CLASS'
,p_column_display_sequence=>2
,p_column_heading=>'LINK_CLASS'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3448438634930123523)
,p_query_column_id=>3
,p_column_alias=>'LINK'
,p_column_display_sequence=>3
,p_column_heading=>'LINK'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3448439086204123523)
,p_query_column_id=>4
,p_column_alias=>'ICON_CLASS'
,p_column_display_sequence=>4
,p_column_heading=>'ICON_CLASS'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3448439507204123524)
,p_query_column_id=>5
,p_column_alias=>'LINK_ATTR'
,p_column_display_sequence=>5
,p_column_heading=>'LINK_ATTR'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3448439810735123525)
,p_query_column_id=>6
,p_column_alias=>'ICON_COLOR_CLASS'
,p_column_display_sequence=>6
,p_column_heading=>'ICON_COLOR_CLASS'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3448440212910123525)
,p_query_column_id=>7
,p_column_alias=>'LIST_CLASS'
,p_column_display_sequence=>7
,p_column_heading=>'LIST_CLASS'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3448441041341123525)
,p_query_column_id=>8
,p_column_alias=>'LIST_TEXT'
,p_column_display_sequence=>9
,p_column_heading=>'LIST_TEXT'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#LIST_TEXT#<br/>',
'#SUBJECT_NAME#'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3448440624635123525)
,p_query_column_id=>9
,p_column_alias=>'LIST_TITLE'
,p_column_display_sequence=>8
,p_column_heading=>'LIST_TITLE'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'#LIST_TITLE#'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3448441480522123526)
,p_query_column_id=>10
,p_column_alias=>'LIST_BADGE'
,p_column_display_sequence=>10
,p_column_heading=>'LIST_BADGE'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3440866092039839717)
,p_query_column_id=>11
,p_column_alias=>'SUBJECT_NAME'
,p_column_display_sequence=>20
,p_column_heading=>'Subject Name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(3448443719529123766)
,p_name=>'L2 Subjects'
,p_template=>wwv_flow_imp.id(16167721656601120494)
,p_display_sequence=>20
,p_region_css_classes=>'js-master-region'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_new_grid_row=>false
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    X."SUBJECT_ID",',
'    UPPER(X."BRANCH_ID") AS "BRANCH",',
'    X."T_INCHARGE_ID" AS "TEACHER ID",',
'    X."TOTAL_CLASS",',
'    y."T_NAME" AS "TEACHER NAME",',
'    y."T_AGE" AS "TEACHER AGE",',
'    y."T_ROLE" AS "TEACHER ROLE",',
'    z."SUBJECT_NAME"',
'FROM',
'    L2_SUBJECTS        X',
'    LEFT JOIN L2_TEACHERS Y',
'    ON X."T_INCHARGE_ID" = Y."T_ID"',
'    LEFT JOIN L2_SUBJECT_DETAILS Z',
'    ON X."SUBJECT_CODE" = Z."SUBJECT_CODE"',
'WHERE',
'    X."SUBJECT_ID" = :P4_SUBJECT_ID'))
,p_display_when_condition=>'P4_SUBJECT_ID'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(16167763074460120512)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No Record Selected'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3448444386825123767)
,p_query_column_id=>1
,p_column_alias=>'SUBJECT_ID'
,p_column_display_sequence=>1
,p_column_heading=>'Subject Id'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from "L2_SUBJECTS"',
'where "SUBJECT_ID" is not null',
'and "SUBJECT_ID" = :P4_SUBJECT_ID'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3440867005945839726)
,p_query_column_id=>2
,p_column_alias=>'BRANCH'
,p_column_display_sequence=>41
,p_column_heading=>'Branch'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3440867094513839727)
,p_query_column_id=>3
,p_column_alias=>'TEACHER ID'
,p_column_display_sequence=>81
,p_column_heading=>'Teacher Id'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3448445974723123768)
,p_query_column_id=>4
,p_column_alias=>'TOTAL_CLASS'
,p_column_display_sequence=>91
,p_column_heading=>'Total Class'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from "L2_SUBJECTS"',
'where "TOTAL_CLASS" is not null',
'and "SUBJECT_ID" = :P4_SUBJECT_ID'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3440867154353839728)
,p_query_column_id=>5
,p_column_alias=>'TEACHER NAME'
,p_column_display_sequence=>51
,p_column_heading=>'Teacher Name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3440867234241839729)
,p_query_column_id=>6
,p_column_alias=>'TEACHER AGE'
,p_column_display_sequence=>61
,p_column_heading=>'Teacher Age'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3440867355713839730)
,p_query_column_id=>7
,p_column_alias=>'TEACHER ROLE'
,p_column_display_sequence=>71
,p_column_heading=>'Teacher Role'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3440866820317839725)
,p_query_column_id=>8
,p_column_alias=>'SUBJECT_NAME'
,p_column_display_sequence=>11
,p_column_heading=>'Subject Name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3448450036893123771)
,p_plug_name=>'Region Display Selector'
,p_region_css_classes=>'js-detail-rds'
,p_region_template_options=>'#DEFAULT#:margin-bottom-md'
,p_plug_template=>wwv_flow_imp.id(16167655060117120468)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_query_num_rows=>15
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P4_SUBJECT_ID'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'Y',
  'rds_mode', 'STANDARD',
  'remember_selection', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3448464255971123976)
,p_plug_name=>'No Record Selected'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16167655060117120468)
,p_plug_display_sequence=>70
,p_location=>null
,p_plug_source=>'No Record Selected'
,p_plug_display_condition_type=>'ITEM_IS_NULL'
,p_plug_display_when_condition=>'P4_SUBJECT_ID'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3448464794687123976)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(3448443719529123766)
,p_button_name=>'EDIT'
,p_button_static_id=>'edit_master_btn'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(16167795321714120528)
,p_button_image_alt=>'Edit'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:5:&APP_SESSION.::&DEBUG.:RP,5:P5_SUBJECT_ID:&P4_SUBJECT_ID.'
,p_icon_css_classes=>'fa-pencil-square-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3448435632551123519)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3448434840858123515)
,p_button_name=>'RESET'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft:t-Button--gapRight'
,p_button_template_id=>wwv_flow_imp.id(16167795321714120528)
,p_button_image_alt=>'Reset'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:4:&APP_SESSION.:RESET:&DEBUG.:RP,4::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3456132805806124339)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3440867488320839731)
,p_button_name=>'Remove'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--danger:t-Button--simple'
,p_button_template_id=>wwv_flow_imp.id(16167795204145120528)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Remove Students'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3456133052535124342)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3448450442596123772)
,p_button_name=>'Assign'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(16167795204145120528)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Assign Students'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3448436009284123519)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(3448434840858123515)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(16167795321714120528)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:5:&APP_SESSION.::&DEBUG.:RP,5::'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3440868500664839741)
,p_name=>'P4_SUBJECT_ID'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3448436866880123520)
,p_name=>'P4_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(3448436405671123519)
,p_prompt=>'Search'
,p_placeholder=>'Search...'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(16167792463926120526)
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large:t-Form-fieldContainer--postTextBlock'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3448465080994123976)
,p_name=>'Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(3448443719529123766)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3448465677270123977)
,p_event_id=>wwv_flow_imp.id(3448465080994123976)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(3448443719529123766)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3448466169796123977)
,p_event_id=>wwv_flow_imp.id(3448465080994123976)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.message.showPageSuccess(''L2 Subjects row(s) updated.'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3448450582251123772)
,p_name=>'Dialog Closed'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(3448450442596123772)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3448455332937123901)
,p_event_id=>wwv_flow_imp.id(3448450582251123772)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(3448450442596123772)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3448455896048123901)
,p_event_id=>wwv_flow_imp.id(3448450582251123772)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.message.showPageSuccess(''L2 Students Subjects row(s) updated.'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3448465199413123976)
,p_name=>'Perform Search'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P4_SEARCH'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.browserEvent.which === apex.jQuery.ui.keyCode.ENTER'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keypress'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3448466982469123977)
,p_event_id=>wwv_flow_imp.id(3448465199413123976)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(3448437179697123520)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3448467506098123978)
,p_event_id=>wwv_flow_imp.id(3448465199413123976)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CANCEL_EVENT'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3456132858472124340)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Remove Assigned Students'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'BEGIN',
'    FOR I IN 1..APEX_APPLICATION.G_F01.COUNT LOOP',
'        DELETE FROM L2_STUDENTS_SUBJECTS X',
'        WHERE',
'            X."SUBJECT_ID" = :P4_SUBJECT_ID',
'            AND X."USN" IN (',
'                SELECT',
'                    USN',
'                FROM',
'                    L2_STUDENTS Y',
'                WHERE',
'                    Y."STD_ROW_NO" = TO_NUMBER(APEX_APPLICATION.G_F01(I))',
'            );',
'    END LOOP;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(3456132805806124339)
,p_internal_uid=>21549093750979109738
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3456132969988124341)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Assign Student To Subjects'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'BEGIN',
'FOR I in 1..APEX_APPLICATION.G_F01.COUNT LOOP',
'        INSERT INTO L2_STUDENTS_SUBJECTS (SUBJECT_ID, USN)',
'        SELECT X."SUBJECT_ID", Y."USN"',
'        FROM L2_SUBJECTS X',
'        LEFT JOIN L2_STUDENTS Y ON X."BRANCH_ID" = Y."BRANCH_ID"',
'        WHERE X."SUBJECT_ID" = :P4_SUBJECT_ID',
'          AND Y."STD_ROW_NO" = TO_NUMBER(APEX_APPLICATION.G_F01(I)); ',
'END LOOP;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(3456133052535124342)
,p_internal_uid=>21549093862495109739
);
wwv_flow_imp.component_end;
end;
/
