prompt --application/pages/page_00010
begin
--   Manifest
--     PAGE: 00010
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>6454551044931893974
,p_default_application_id=>193996
,p_default_id_offset=>18092960892506985398
,p_default_owner=>'WKSP_INOAUG091DARKMODE'
);
wwv_flow_imp_page.create_page(
 p_id=>10
,p_name=>'L2 Classes'
,p_alias=>'L2-CLASSES'
,p_page_mode=>'MODAL'
,p_step_title=>'L2 Classes'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(16167618819573120451)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3468934590293749249)
,p_plug_name=>'L2 Classes'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16167655060117120468)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'L2_CLASSES'
,p_include_rowid_column=>true
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3468938435544749252)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16167657848050120469)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3468938820711749252)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3468938435544749252)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(16167795204145120528)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3468940246778749253)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(3468938435544749252)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--danger:t-Button--simple'
,p_button_template_id=>wwv_flow_imp.id(16167795204145120528)
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P10_ROWID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
,p_required_patch=>wwv_flow_imp.id(16167617495353120450)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3468940627139749254)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(3468938435544749252)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(16167795204145120528)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_condition=>'P10_ROWID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
,p_required_patch=>wwv_flow_imp.id(16167617495353120450)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3472197981243859521)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(3468938435544749252)
,p_button_name=>'Add'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(16167795204145120528)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Class'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3472198026801859522)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(3468938435544749252)
,p_button_name=>'Remove'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--danger'
,p_button_template_id=>wwv_flow_imp.id(16167795204145120528)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Remove Class'
,p_button_position=>'NEXT'
,p_required_patch=>wwv_flow_imp.id(16167617495353120450)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3468941018890749254)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(3468938435544749252)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(16167795204145120528)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'NEXT'
,p_button_condition=>'P10_ROWID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
,p_required_patch=>wwv_flow_imp.id(16167617495353120450)
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3468934962413749249)
,p_name=>'P10_ROWID'
,p_source_data_type=>'VARCHAR2'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(3468934590293749249)
,p_item_source_plug_id=>wwv_flow_imp.id(3468934590293749249)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Rowid'
,p_source=>'ROWID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(16167792785719120526)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3468935806495749250)
,p_name=>'P10_CLASS_NO'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(3468934590293749249)
,p_item_source_plug_id=>wwv_flow_imp.id(3468934590293749249)
,p_prompt=>'Class No'
,p_source=>'CLASS_NO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(16167794093758120527)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3468936107600749250)
,p_name=>'P10_SUBJECT_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(3468934590293749249)
,p_item_source_plug_id=>wwv_flow_imp.id(3468934590293749249)
,p_item_default=>'SELECT :P8_SUBJECT_ID FROM DUAL;'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Subject Id'
,p_source=>'SUBJECT_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(16167794093758120527)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3468936558451749251)
,p_name=>'P10_CLASS_DATE'
,p_source_data_type=>'DATE'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(3468934590293749249)
,p_item_source_plug_id=>wwv_flow_imp.id(3468934590293749249)
,p_prompt=>'Class Date'
,p_source=>'CLASS_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(16167794093758120527)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3472198449668859526)
,p_name=>'P10_CLASS_ID'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(3468934590293749249)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3468938974157749252)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(3468938820711749252)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3468939768770749253)
,p_event_id=>wwv_flow_imp.id(3468938974157749252)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3472197840111859520)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create Class'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    TOTAL_CLASSES INT;',
'    CLASS_ID_VAL  INT;',
'    TOTAL_STUDENTS INT;',
'BEGIN',
'    SELECT COUNT(*) INTO TOTAL_STUDENTS ',
'    FROM L2_STUDENTS_SUBJECTS X',
'        WHERE',
'            X.SUBJECT_ID = :P10_SUBJECT_ID;',
'    IF TOTAL_STUDENTS > 0 THEN',
'        SELECT',
'            TOTAL_CLASS INTO TOTAL_CLASSES',
'        FROM',
'            L2_SUBJECTS',
'        WHERE',
'            SUBJECT_ID = :P10_SUBJECT_ID;',
'        INSERT INTO L2_CLASSES (',
'            CLASS_NO,',
'            SUBJECT_ID,',
'            CLASS_DATE',
'        ) VALUES (',
'            :P10_CLASS_NO,',
'            :P10_SUBJECT_ID,',
'            (TO_DATE(:P10_CLASS_DATE, ''MM/DD/YYYY''))',
'        ) RETURNING CLASS_ID INTO CLASS_ID_VAL;',
'        INSERT INTO L2_STUDENTS_ATTEND (',
'            CLASS_ID,',
'            USN,',
'            ATTENDANCE',
'        )',
'            SELECT',
'                CLASS_ID_VAL,',
'                X.USN,',
'                ''N''',
'            FROM',
'                L2_STUDENTS_SUBJECTS X',
'            WHERE',
'                X.SUBJECT_ID = :P10_SUBJECT_ID;',
'        UPDATE L2_SUBJECTS',
'        SET',
'            TOTAL_CLASS = (',
'                TOTAL_CLASSES + 1',
'            )',
'        WHERE',
'            SUBJECT_ID = :P10_SUBJECT_ID;',
'    ELSE',
'        RAISE_APPLICATION_ERROR(-20003, ''Min 1 Students required to Create Class.'');',
'    END IF;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(3472197981243859521)
,p_internal_uid=>21565158732618844918
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3468941822943749254)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(3468934590293749249)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form L2 Classes'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>21561902715450734652
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3468942246159749255)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_01=>'P10_ROWID,REQUEST'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>21561903138666734653
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3468941443789749254)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(3468934590293749249)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form L2 Classes'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>21561902336296734652
);
wwv_flow_imp.component_end;
end;
/
