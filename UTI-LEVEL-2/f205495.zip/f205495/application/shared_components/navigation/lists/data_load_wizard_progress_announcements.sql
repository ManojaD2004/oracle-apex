prompt --application/shared_components/navigation/lists/data_load_wizard_progress_announcements
begin
--   Manifest
--     LIST: Data Load Wizard Progress - Announcements
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>6454551044931893974
,p_default_application_id=>193996
,p_default_id_offset=>18092960892506985398
,p_default_owner=>'WKSP_INOAUG091DARKMODE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(16179619396667535358)
,p_name=>'Data Load Wizard Progress - Announcements'
,p_list_status=>'PUBLIC'
,p_version_scn=>15546300784364
);
wwv_flow_imp.component_end;
end;
/
