prompt --application/shared_components/user_interface/themes
begin
--   Manifest
--     THEME: 205495
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>6454551044931893974
,p_default_application_id=>193996
,p_default_id_offset=>18092960892506985398
,p_default_owner=>'WKSP_INOAUG091DARKMODE'
);
wwv_flow_imp_shared.create_theme(
 p_id=>wwv_flow_imp.id(16167885252291120634)
,p_theme_id=>42
,p_theme_name=>'Universal Theme'
,p_theme_internal_name=>'UNIVERSAL_THEME'
,p_version_identifier=>'24.1'
,p_navigation_type=>'L'
,p_nav_bar_type=>'LIST'
,p_reference_id=>4070917134413059350
,p_is_locked=>false
,p_default_page_template=>wwv_flow_imp.id(16167644976112120463)
,p_default_dialog_template=>wwv_flow_imp.id(16167639793734120461)
,p_error_template=>wwv_flow_imp.id(16167629737640120457)
,p_printer_friendly_template=>wwv_flow_imp.id(16167644976112120463)
,p_breadcrumb_display_point=>'REGION_POSITION_01'
,p_sidebar_display_point=>'REGION_POSITION_02'
,p_login_template=>wwv_flow_imp.id(16167629737640120457)
,p_default_button_template=>wwv_flow_imp.id(16167795204145120528)
,p_default_region_template=>wwv_flow_imp.id(16167721656601120494)
,p_default_chart_template=>wwv_flow_imp.id(16167721656601120494)
,p_default_form_template=>wwv_flow_imp.id(16167721656601120494)
,p_default_reportr_template=>wwv_flow_imp.id(16167721656601120494)
,p_default_tabform_template=>wwv_flow_imp.id(16167721656601120494)
,p_default_wizard_template=>wwv_flow_imp.id(16167721656601120494)
,p_default_menur_template=>wwv_flow_imp.id(16167734083956120499)
,p_default_listr_template=>wwv_flow_imp.id(16167721656601120494)
,p_default_irr_template=>wwv_flow_imp.id(16167711835329120490)
,p_default_report_template=>wwv_flow_imp.id(16167760067793120511)
,p_default_label_template=>wwv_flow_imp.id(16167792785719120526)
,p_default_menu_template=>wwv_flow_imp.id(16167796800214120528)
,p_default_calendar_template=>wwv_flow_imp.id(16167796971950120528)
,p_default_list_template=>wwv_flow_imp.id(16167776691842120519)
,p_default_nav_list_template=>wwv_flow_imp.id(16167788489447120524)
,p_default_top_nav_list_temp=>wwv_flow_imp.id(16167788489447120524)
,p_default_side_nav_list_temp=>wwv_flow_imp.id(16167783051236120522)
,p_default_nav_list_position=>'SIDE'
,p_default_dialogbtnr_template=>wwv_flow_imp.id(16167657848050120469)
,p_default_dialogr_template=>wwv_flow_imp.id(16167655060117120468)
,p_default_option_label=>wwv_flow_imp.id(16167792785719120526)
,p_default_required_label=>wwv_flow_imp.id(16167794093758120527)
,p_default_navbar_list_template=>wwv_flow_imp.id(16167782677353120521)
,p_file_prefix => nvl(wwv_flow_application_install.get_static_theme_file_prefix(42),'#APEX_FILES#themes/theme_42/24.1/')
,p_files_version=>65
,p_icon_library=>'FONTAPEX'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/apex/#MIN_DIRECTORY#widget.stickyWidget#MIN#.js?v=#APEX_VERSION#',
'#THEME_FILES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>'#THEME_FILES#css/Core#MIN#.css?v=#APEX_VERSION#'
);
wwv_flow_imp.component_end;
end;
/
