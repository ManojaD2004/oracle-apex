prompt --application/shared_components/user_interface/lovs/l1_branch_branch_name
begin
--   Manifest
--     L1_BRANCH.BRANCH_NAME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>6454551044931893974
,p_default_application_id=>193996
,p_default_id_offset=>18092960892506985398
,p_default_owner=>'WKSP_INOAUG091DARKMODE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(16169727643607408943)
,p_lov_name=>'L1_BRANCH.BRANCH_NAME'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'L1_BRANCH'
,p_return_column_name=>'BRANCH_ID'
,p_display_column_name=>'BRANCH_NAME'
,p_default_sort_column_name=>'BRANCH_NAME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>15546287312199
);
wwv_flow_imp.component_end;
end;
/
