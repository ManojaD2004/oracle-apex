prompt --application/shared_components/logic/application_items/get_role
begin
--   Manifest
--     APPLICATION ITEM: GET_ROLE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>6454551044931893974
,p_default_application_id=>193996
,p_default_id_offset=>18092960892506985398
,p_default_owner=>'WKSP_INOAUG091DARKMODE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(3445915366047745948)
,p_name=>'GET_ROLE'
,p_protection_level=>'I'
,p_version_scn=>15550460979022
);
wwv_flow_imp.component_end;
end;
/
