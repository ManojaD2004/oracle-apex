prompt --application/shared_components/legacy_data_loads/l1_announcement
begin
--   Manifest
--     L1_ANNOUNCEMENT
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>6454551044931893974
,p_default_application_id=>193996
,p_default_id_offset=>18092960892506985398
,p_default_owner=>'WKSP_INOAUG091DARKMODE'
);
wwv_flow_imp_shared.create_load_table(
 p_id=>wwv_flow_imp.id(16179619115055535355)
,p_name=>'Announcements'
,p_owner=>'#OWNER#'
,p_table_name=>'L1_ANNOUNCEMENT'
,p_unique_column_1=>'ANNOUNCEMENT_ID'
,p_is_uk1_case_sensitive=>'N'
,p_is_uk2_case_sensitive=>'N'
,p_is_uk3_case_sensitive=>'N'
,p_skip_validation=>'N'
);
wwv_flow_imp.component_end;
end;
/
