prompt --workspace/credentials/ai_oci
begin
--   Manifest
--     CREDENTIAL: AI_OCI
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>6454551044931893974
,p_default_application_id=>193996
,p_default_id_offset=>18092960892506985398
,p_default_owner=>'WKSP_INOAUG091DARKMODE'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(6211056096837613280)
,p_name=>'AI_OCI'
,p_static_id=>'ai_oci'
,p_authentication_type=>'OCI'
,p_namespace=>'ocid1.tenancy.oc1..aaaaaaaaweuxa6ovnhihlbpolrh3jrdpasnnukjd5x5slxcekzwsdigsayza'
,p_prompt_on_install=>true
);
wwv_flow_imp.component_end;
end;
/
